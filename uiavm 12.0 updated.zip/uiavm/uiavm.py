#!/usr/bin/env python3
# uiavm.py - UIAVM: LXC VPS control panel with multi-node clustering        made by reon
#
#   python3 uiavm.py                       start the panel
#   python3 uiavm.py node add --name sg1   create a node and print its one-line install command
#   python3 uiavm.py node list             list nodes
#   python3 uiavm.py admin reset-password  reset the main admin password
#
import argparse
import base64
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import shutil
import sqlite3
import struct
import sys
import threading
import time
from collections import deque, defaultdict
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests
from flask import (Flask, Response, abort, flash, g, jsonify, redirect, render_template, request,
                   send_file, session, url_for)
from flask_login import (LoginManager, UserMixin, current_user, login_required, login_user, logout_user)
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash, generate_password_hash

try:
    from flask_socketio import SocketIO, emit, join_room, leave_room
    SOCKETIO = True
except ImportError:  # panel still works, minus console + push events
    SOCKETIO = False

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))
import uiavm_node as agent  # shared with the node agent: same code for local + remote nodes
agent.STATE_DIR = str(BASE_DIR)   # the panel's own node keeps its Docker port-forward state next to the database

# ============================================================================ config
def env(name, default=None):
    return os.getenv("UIAVM_" + name, default)

PANEL_NAME = env("NAME", "UIAVM")
PANEL_VERSION = "12.1"
PANEL_AUTHOR = "reon"
DB_PATH = env("DB", str(BASE_DIR / "uiavm.db"))
HOST = env("HOST", "0.0.0.0")
PORT = int(env("PORT", 5000))
PUBLIC_URL = (env("PUBLIC_URL", "") or "").rstrip("/")
STORAGE_POOL = env("STORAGE_POOL", "default")
DEBUG = env("DEBUG", "0").lower() in ("1", "true", "yes")
POLL_INTERVAL = max(2, int(env("POLL_INTERVAL", 5)))
BACKUP_INTERVAL = int(env("BACKUP_INTERVAL", 3600))
ADMIN_USER = env("ADMIN_USER", "admin")
ADMIN_EMAIL = env("ADMIN_EMAIL", "admin@gmail.com")
ADMIN_PASSWORD = env("ADMIN_PASSWORD", "admin@123")   # default first-run admin - change it after signing in
RESET_ADMIN = env("RESET_ADMIN", "0").lower() in ("1", "true", "yes")   # force the main admin back to the values above
DEFAULT_NODE_PORT = 7071
HISTORY_LEN = 120

OS_OPTIONS = [
    {"label": "Ubuntu 24.04 LTS", "value": "ubuntu:24.04", "icon": "ubuntu"},
    {"label": "Ubuntu 22.04 LTS", "value": "ubuntu:22.04", "icon": "ubuntu"},
    {"label": "Ubuntu 20.04 LTS", "value": "ubuntu:20.04", "icon": "ubuntu"},
    {"label": "Debian 13 (Trixie)", "value": "images:debian/13", "icon": "debian"},
    {"label": "Debian 12 (Bookworm)", "value": "images:debian/12", "icon": "debian"},
    {"label": "Debian 11 (Bullseye)", "value": "images:debian/11", "icon": "debian"},
    {"label": "Alpine 3.21", "value": "images:alpine/3.21", "icon": "alpine"},
    {"label": "Alpine 3.20", "value": "images:alpine/3.20", "icon": "alpine"},
    {"label": "Fedora 42", "value": "images:fedora/42", "icon": "fedora"},
    {"label": "Fedora 41", "value": "images:fedora/41", "icon": "fedora"},
    {"label": "Rocky Linux 9", "value": "images:rockylinux/9", "icon": "rocky"},
    {"label": "AlmaLinux 9", "value": "images:almalinux/9", "icon": "alma"},
    {"label": "CentOS 9 Stream", "value": "images:centos/9-Stream", "icon": "centos"},
    {"label": "Arch Linux", "value": "images:archlinux", "icon": "arch"},
]
RUNTIME_LABEL = {"lxc": "LXC", "docker": "Docker"}
DOCKER_IMAGES = [
    {"label": "Ubuntu 24.04", "value": "ubuntu:24.04", "icon": "ubuntu", "keepalive": True},
    {"label": "Ubuntu 22.04", "value": "ubuntu:22.04", "icon": "ubuntu", "keepalive": True},
    {"label": "Debian 12", "value": "debian:12", "icon": "debian", "keepalive": True},
    {"label": "Alpine 3.20", "value": "alpine:3.20", "icon": "alpine", "keepalive": True},
    {"label": "Rocky Linux 9", "value": "rockylinux:9", "icon": "rocky", "keepalive": True},
    {"label": "Python 3.12", "value": "python:3.12-slim", "icon": "python", "keepalive": True},
    {"label": "Node.js 22", "value": "node:22-slim", "icon": "node", "keepalive": True},
    {"label": "Nginx web server", "value": "nginx:stable", "icon": "nginx", "keepalive": False},
    {"label": "Redis 7", "value": "redis:7", "icon": "redis", "keepalive": False},
]
# how much freedom a container gets. "docker" is the safe default: docker/podman work, root-in-container is not root-on-host
CONTAINER_PROFILES = {
    "standard": "Standard - isolated, no nesting",
    "docker": "Docker-ready - nesting + FUSE, still unprivileged",
    "privileged": "Privileged - full access (unsafe, trusted users only)",
}

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s",
                    handlers=[logging.FileHandler(BASE_DIR / "uiavm.log"), logging.StreamHandler()])
logger = logging.getLogger("uiavm")
logging.getLogger("werkzeug").setLevel(logging.WARNING)


def _secret_key():
    if env("SECRET_KEY"):
        return env("SECRET_KEY")
    p = BASE_DIR / ".uiavm_secret"          # persisted so restarts don't log everyone out
    if p.exists():
        return p.read_text().strip()
    k = secrets.token_urlsafe(48)
    p.write_text(k)
    os.chmod(p, 0o600)
    return k


app = Flask(__name__, template_folder=str(BASE_DIR / "templates"), static_folder=str(BASE_DIR / "static"))
app.config.update(SECRET_KEY=_secret_key(), PERMANENT_SESSION_LIFETIME=timedelta(days=1),
                  MAX_CONTENT_LENGTH=8 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True,
                  SESSION_COOKIE_SAMESITE="Lax", TEMPLATES_AUTO_RELOAD=DEBUG)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1)
socketio = SocketIO(app, cors_allowed_origins=None, async_mode="threading", ping_timeout=60) if SOCKETIO else None

login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message_category = "warn"


# ============================================================================ database
@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.row_factory = sqlite3.Row
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def q(sql, params=(), one=False):
    with get_db() as c:
        rows = c.execute(sql, params).fetchall()
    return (dict(rows[0]) if rows else None) if one else [dict(r) for r in rows]


def x(sql, params=()):
    """Execute a write, return lastrowid."""
    with get_db() as c:
        return c.execute(sql, params).lastrowid


def now_iso():
    return datetime.now().isoformat()


def ensure_columns(conn, table, cols):
    have = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
    for name, ddl in cols.items():
        if name not in have:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")


def migrate_legacy_db():
    """First run after the rename: adopt the old hvm.db so nothing is lost."""
    if os.path.exists(DB_PATH):
        return
    for cand in (BASE_DIR / "hvm.db", Path.cwd() / "hvm.db"):
        if cand.exists():
            logger.info(f"Found legacy database {cand} - importing into {DB_PATH}")
            src = sqlite3.connect(str(cand))
            dst = sqlite3.connect(DB_PATH)
            src.backup(dst)                      # consistent copy, handles WAL
            src.close(); dst.close()
            return


def init_db():
    migrate_legacy_db()
    with get_db() as conn:
        c = conn.cursor()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, is_admin INTEGER DEFAULT 0,
            is_main_admin INTEGER DEFAULT 0, created_at TEXT NOT NULL, last_login TEXT, last_active TEXT,
            api_key TEXT UNIQUE, profile_picture TEXT, preferences TEXT DEFAULT '{}', two_factor_secret TEXT,
            two_factor_enabled INTEGER DEFAULT 0, theme TEXT DEFAULT 'ion', language TEXT DEFAULT 'en');
        CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            type TEXT NOT NULL, title TEXT NOT NULL, message TEXT NOT NULL, read INTEGER DEFAULT 0,
            created_at TEXT NOT NULL, expires_at TEXT, data TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
        CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, read);
        CREATE TABLE IF NOT EXISTS nodes (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL,
            location TEXT, total_vps INTEGER DEFAULT 50, used_vps INTEGER DEFAULT 0, tags TEXT DEFAULT '[]',
            api_key TEXT UNIQUE, api_key_last_used TEXT, url TEXT, is_local INTEGER DEFAULT 0,
            ip_addresses TEXT DEFAULT '[]', ip_aliases TEXT DEFAULT '[]', status TEXT DEFAULT 'unknown',
            last_seen TEXT, cpu_cores INTEGER DEFAULT 0, ram_total INTEGER DEFAULT 0, disk_total INTEGER DEFAULT 0,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS vps (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            node_id INTEGER NOT NULL DEFAULT 1, container_name TEXT UNIQUE NOT NULL, hostname TEXT, ram TEXT NOT NULL,
            cpu TEXT NOT NULL, storage TEXT NOT NULL, config TEXT NOT NULL, os_version TEXT DEFAULT 'ubuntu:22.04',
            status TEXT DEFAULT 'stopped', suspended INTEGER DEFAULT 0, suspended_reason TEXT, whitelisted INTEGER DEFAULT 0,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL, last_started TEXT, last_stopped TEXT,
            backup_schedule TEXT, backup_count INTEGER DEFAULT 0, ip_address TEXT, ip_alias TEXT,
            shared_with TEXT DEFAULT '[]', suspension_history TEXT DEFAULT '[]', notes TEXT, metadata TEXT DEFAULT '{}',
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE RESTRICT);
        CREATE INDEX IF NOT EXISTS idx_vps_user ON vps(user_id);
        CREATE INDEX IF NOT EXISTS idx_vps_node ON vps(node_id);
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, description TEXT, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS port_allocations (user_id INTEGER PRIMARY KEY, allocated_ports INTEGER DEFAULT 0,
            used_ports INTEGER DEFAULT 0, updated_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
        CREATE TABLE IF NOT EXISTS port_forwards (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            vps_container TEXT NOT NULL, vps_port INTEGER NOT NULL, host_port INTEGER NOT NULL, protocol TEXT DEFAULT 'tcp,udp',
            description TEXT, created_at TEXT NOT NULL, last_used TEXT, hits INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(vps_container) REFERENCES vps(container_name) ON DELETE CASCADE);
        CREATE INDEX IF NOT EXISTS idx_pf_user ON port_forwards(user_id);
        CREATE INDEX IF NOT EXISTS idx_pf_container ON port_forwards(vps_container);
        CREATE TABLE IF NOT EXISTS activity_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL,
            resource_type TEXT, resource_id TEXT, details TEXT, ip_address TEXT, user_agent TEXT, created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL);
        CREATE INDEX IF NOT EXISTS idx_log_created ON activity_logs(created_at);
        CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires TEXT NOT NULL, data TEXT,
            ip_address TEXT, user_agent TEXT, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS backups (id INTEGER PRIMARY KEY AUTOINCREMENT, vps_id INTEGER NOT NULL, name TEXT NOT NULL,
            size INTEGER DEFAULT 0, path TEXT NOT NULL, created_at TEXT NOT NULL, expires_at TEXT, status TEXT DEFAULT 'completed');
        CREATE TABLE IF NOT EXISTS os_icons (id INTEGER PRIMARY KEY AUTOINCREMENT, os_name TEXT UNIQUE NOT NULL,
            icon_path TEXT NOT NULL, uploaded_at TEXT NOT NULL, uploaded_by INTEGER);
        """)
        # additive migrations (safe to run on a database made by the old HVM panel)
        ensure_columns(conn, "nodes", {"drain": "INTEGER DEFAULT 0", "agent_version": "TEXT", "lxc_version": "TEXT",
                                       "agent_port": "INTEGER", "notes": "TEXT"})
        ensure_columns(conn, "vps", {"container_profile": "TEXT DEFAULT 'docker'", "image_label": "TEXT", "runtime": "TEXT DEFAULT 'lxc'"})
        ensure_columns(conn, "nodes", {"docker_version": "TEXT"})
        # the local node is the panel host itself
        if not c.execute("SELECT 1 FROM nodes WHERE is_local=1").fetchone():
            c.execute("INSERT INTO nodes (name,location,total_vps,tags,is_local,ip_addresses,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)",
                      ("Local Node", "Local", 100, "[]", 1, "[]", now_iso(), now_iso()))
        defaults = [
            ("cpu_threshold", "90", "Sustained CPU % that triggers auto-suspend"),
            ("ram_threshold", "95", "Sustained RAM % that triggers auto-suspend"),
            ("auto_suspend", "1", "Auto-suspend abusive VPS (1=on)"),
            ("suspend_grace_minutes", "5", "Minutes a VPS must stay above threshold before suspend"),
            ("site_name", PANEL_NAME, "Site name"),
            ("site_description", "LXC VPS control panel", "Site description"),
            ("footer_text", "UIAVM - made by reon", "Footer text"),
            ("maintenance_mode", "0", "Maintenance mode (1=on)"),
            ("maintenance_message", "UIAVM is under maintenance. Please check back soon.", "Maintenance message"),
            ("registration_enabled", "1", "Allow public registration (1=on)"),
            ("default_port_quota", "5", "Default port-forward quota for new users"),
            ("max_vps_per_user", "10", "Maximum VPS per user"),
            ("max_snapshots", "5", "Maximum snapshots per VPS"),
            ("backup_enabled", "1", "Automatic database backups (1=on)"),
            ("backup_retention", "7", "Database backups to keep"),
            ("bootstrap_packages", "1", "Install curl/wget/htop inside new VPS (1=on)"),
            ("default_profile", "docker", "Default container profile"),
        ]
        for k, v, d in defaults:
            c.execute("INSERT OR IGNORE INTO settings (key,value,description,updated_at) VALUES (?,?,?,?)", (k, v, d, now_iso()))
        # rebrand values the old panel stored
        for k, old, new in (("site_name", "HVM PANEL", PANEL_NAME), ("footer_text", "Powered by HVM Panel", "UIAVM - made by reon"),
                            ("site_description", "High-Performance VPS Management Panel", "LXC VPS control panel")):
            c.execute("UPDATE settings SET value=? WHERE key=? AND value=?", (new, k, old))
        c.execute("UPDATE settings SET value='ion' WHERE key='theme' AND value='default'")
        c.execute("UPDATE users SET theme='ion' WHERE theme IS NULL OR theme='default'")
        c.execute("UPDATE vps SET status='stopped' WHERE status IS NULL")
        # main admin
        if not c.execute("SELECT 1 FROM users WHERE is_main_admin=1").fetchone():
            c.execute("INSERT INTO users (username,email,password_hash,is_admin,is_main_admin,created_at,api_key) VALUES (?,?,?,1,1,?,?)",
                      (ADMIN_USER, ADMIN_EMAIL, generate_password_hash(ADMIN_PASSWORD), now_iso(), secrets.token_urlsafe(48)))
            c.execute("INSERT INTO port_allocations (user_id,allocated_ports,updated_at) VALUES (?,?,?)", (c.lastrowid, 100, now_iso()))
            logger.warning(f"Admin account created: {ADMIN_USER} / {ADMIN_PASSWORD}  -  change the password after signing in.")
        elif RESET_ADMIN:
            c.execute("UPDATE users SET username=?, email=?, password_hash=?, two_factor_enabled=0, two_factor_secret=NULL WHERE is_main_admin=1",
                      (ADMIN_USER, ADMIN_EMAIL, generate_password_hash(ADMIN_PASSWORD)))
            logger.warning(f"Main admin reset to {ADMIN_USER} / {ADMIN_EMAIL}")
        # keep node usage counters honest
        c.execute("UPDATE nodes SET used_vps=(SELECT COUNT(*) FROM vps WHERE vps.node_id=nodes.id)")


def get_setting(key, default=None):
    r = q("SELECT value FROM settings WHERE key=?", (key,), one=True)
    return r["value"] if r else default


def set_setting(key, value):
    x("INSERT INTO settings (key,value,updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
      (key, str(value), now_iso()))


def new_token(n=32):
    return secrets.token_urlsafe(n)


def jl(s, default):
    try:
        v = json.loads(s) if isinstance(s, str) else s
        return v if v is not None else default
    except Exception:
        return default


# ============================================================================ activity + notifications
def log_activity(user_id, action, rtype=None, rid=None, details=None):
    try:
        ip = ua = None
        try:
            ip, ua = request.remote_addr, request.user_agent.string
        except RuntimeError:
            pass
        x("INSERT INTO activity_logs (user_id,action,resource_type,resource_id,details,ip_address,user_agent,created_at) VALUES (?,?,?,?,?,?,?,?)",
          (user_id, action, rtype, str(rid) if rid is not None else None, json.dumps(details) if details else None, ip, ua, now_iso()))
    except Exception as e:
        logger.error(f"activity log failed: {e}")


def notify(user_id, ntype, title, message, data=None, ttl=None):
    """ntype: success | info | warn | error"""
    try:
        exp = (datetime.now() + timedelta(seconds=ttl)).isoformat() if ttl else None
        nid = x("INSERT INTO notifications (user_id,type,title,message,created_at,expires_at,data) VALUES (?,?,?,?,?,?,?)",
                (user_id, ntype, title, message, now_iso(), exp, json.dumps(data) if data else None))
        push(f"user_{user_id}", "notification", {"id": nid, "type": ntype, "title": title, "message": message})
    except Exception as e:
        logger.error(f"notify failed: {e}")


def push(room, event, payload):
    if socketio:
        try:
            socketio.emit(event, payload, to=room)
        except Exception as e:
            logger.debug(f"emit failed: {e}")


def unread_count(user_id):
    return q("SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read=0 AND (expires_at IS NULL OR expires_at>?)",
             (user_id, now_iso()), one=True)["n"]


# ============================================================================ security helpers
def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_urlsafe(24)
    return session["_csrf"]


_login_attempts: Dict[str, deque] = defaultdict(deque)


def rate_limited(key, limit=8, window=300):
    now = time.time()
    dq = _login_attempts[key]
    while dq and now - dq[0] > window:
        dq.popleft()
    return len(dq) >= limit


def rate_hit(key):
    _login_attempts[key].append(time.time())


def totp(secret, t=None, step=30, digits=6):
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    h = hmac.new(key, struct.pack(">Q", int((t or time.time()) // step)), "sha1").digest()
    o = h[-1] & 15
    return f"{(struct.unpack('>I', h[o:o + 4])[0] & 0x7fffffff) % 10 ** digits:0{digits}d}"


def totp_verify(secret, code):
    code = (code or "").strip().replace(" ", "")
    return any(hmac.compare_digest(totp(secret, time.time() + d * 30), code) for d in (-1, 0, 1))


@app.before_request
def guard():
    ep = request.endpoint or ""
    # CSRF for browser sessions (API-key + node endpoints authenticate themselves)
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and not request.path.startswith(("/api/v1/", "/api/node/", "/node/")):
        sent = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token")
        if not sent or not hmac.compare_digest(sent, session.get("_csrf", "")):
            if request.is_json or request.path.startswith("/api/") or request.headers.get("X-CSRF-Token") is not None or request.accept_mimetypes.best == "application/json":
                return jsonify(success=False, error="Session expired - reload the page."), 400
            flash("Your session expired. Please try again.", "warn")
            return redirect(request.referrer or url_for("login"))
    # maintenance mode
    if ep in ("static", "login", "logout", "twofa", "health", "node_install", "node_agent_file", "node_register") or request.path.startswith(("/api/node/", "/node/", "/static/")):
        return None
    if get_setting("maintenance_mode", "0") == "1":
        if current_user.is_authenticated and current_user.is_admin:
            return None
        return render_template("maintenance.html", message=get_setting("maintenance_message")), 503


@app.after_request
def secure_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    if request.path.startswith("/api/") or request.is_json:
        resp.headers["Cache-Control"] = "no-store"
    return resp


# ============================================================================ users
class User(UserMixin):
    def __init__(self, d):
        self.id = d["id"]
        self.username = d["username"]
        self.email = d["email"]
        self.password_hash = d["password_hash"]
        self.is_admin = bool(d["is_admin"])
        self.is_main_admin = bool(d["is_main_admin"])
        self.created_at = d["created_at"]
        self.last_login = d.get("last_login")
        self.api_key = d.get("api_key")
        self.two_factor_enabled = bool(d.get("two_factor_enabled"))
        self.two_factor_secret = d.get("two_factor_secret")
        self.theme = d.get("theme") or "ion"
        self.preferences = jl(d.get("preferences"), {})

    @staticmethod
    def by(field, value):
        assert field in ("id", "username", "email", "api_key")
        r = q(f"SELECT * FROM users WHERE {field}=?", (value,), one=True)
        return User(r) if r else None


@login_manager.user_loader
def load_user(uid):
    return User.by("id", int(uid))


def admin_required(f):
    @wraps(f)
    def w(*a, **k):
        if not current_user.is_authenticated:
            return login_manager.unauthorized()
        if not current_user.is_admin:
            if request.is_json or request.path.startswith("/api/"):
                return jsonify(success=False, error="Admin access required"), 403
            flash("Admin access required.", "error")
            return redirect(url_for("dashboard"))
        return f(*a, **k)
    return w


def api_key_required(f):
    @wraps(f)
    def w(*a, **k):
        key = request.headers.get("X-API-Key") or (request.headers.get("Authorization", "")[7:] if request.headers.get("Authorization", "").startswith("Bearer ") else None)
        u = User.by("api_key", key) if key else None
        if not u:
            return jsonify(error="invalid or missing API key"), 401
        request.api_user = u
        return f(*a, **k)
    return w


def can_access_vps(user, vps):
    return bool(vps) and (user.is_admin or vps["user_id"] == user.id or user.id in [int(i) for i in vps["shared_with"] if str(i).isdigit()])


# ============================================================================ generic row helpers
VPS_COLS = {"user_id", "node_id", "container_name", "hostname", "ram", "cpu", "storage", "config", "os_version", "status",
            "suspended", "suspended_reason", "whitelisted", "last_started", "last_stopped", "ip_address", "ip_alias",
            "shared_with", "suspension_history", "notes", "metadata", "container_profile", "image_label", "runtime"}
NODE_COLS = {"name", "location", "total_vps", "tags", "api_key", "api_key_last_used", "url", "ip_addresses", "ip_aliases",
             "status", "last_seen", "cpu_cores", "ram_total", "disk_total", "drain", "agent_version", "lxc_version",
             "agent_port", "notes", "used_vps", "docker_version"}
JSON_COLS = {"shared_with", "suspension_history", "metadata", "tags", "ip_addresses", "ip_aliases"}


def update_row(table, row_id, allowed, **kw):
    if not kw:
        return
    sets, vals = [], []
    for k, v in kw.items():
        if k not in allowed:
            raise ValueError(f"column {k} not updatable")
        sets.append(f"{k}=?")
        vals.append(json.dumps(v) if k in JSON_COLS and not isinstance(v, str) else v)
    # NOTE: values first, then updated_at, then the id - the old panel had these swapped, so its updates never saved
    x(f"UPDATE {table} SET {', '.join(sets)}, updated_at=? WHERE id=?", (*vals, now_iso(), row_id))


def update_vps(vps_id, **kw):
    update_row("vps", vps_id, VPS_COLS, **kw)


def update_node(node_id, **kw):
    update_row("nodes", node_id, NODE_COLS, **kw)


def _node(r):
    if not r:
        return None
    for k in ("tags", "ip_addresses", "ip_aliases"):
        r[k] = jl(r.get(k), [])
    return r


def get_nodes():
    return [_node(r) for r in q("SELECT * FROM nodes ORDER BY is_local DESC, name")]


def get_node(node_id):
    return _node(q("SELECT * FROM nodes WHERE id=?", (node_id,), one=True)) if node_id is not None else None


def _vps(r):
    if not r:
        return None
    for k in ("shared_with", "suspension_history"):
        r[k] = jl(r.get(k), [])
    r["metadata"] = jl(r.get("metadata"), {})
    r["suspended"] = bool(r.get("suspended"))
    r["whitelisted"] = bool(r.get("whitelisted"))
    return r


VPS_SELECT = ("SELECT v.*, u.username AS owner, n.name AS node_name, n.location AS node_location FROM vps v "
              "LEFT JOIN users u ON u.id=v.user_id LEFT JOIN nodes n ON n.id=v.node_id ")


def get_vps(vps_id):
    return _vps(q(VPS_SELECT + "WHERE v.id=?", (vps_id,), one=True))


def get_all_vps():
    return [_vps(r) for r in q(VPS_SELECT + "ORDER BY v.created_at DESC")]


def get_vps_for_user(uid):
    rows = [_vps(r) for r in q(VPS_SELECT + "ORDER BY v.created_at DESC")]
    return [v for v in rows if v["user_id"] == uid or uid in [int(i) for i in v["shared_with"] if str(i).isdigit()]]


def node_vps_count(node_id):
    return q("SELECT COUNT(*) n FROM vps WHERE node_id=?", (node_id,), one=True)["n"]


def refresh_node_counts():
    x("UPDATE nodes SET used_vps=(SELECT COUNT(*) FROM vps WHERE vps.node_id=nodes.id)")


# ============================================================================ talking to nodes
class NodeError(Exception):
    pass


TLS_VERIFY = env("NODE_TLS_VERIFY", "1") != "0"
NAME_RE = re.compile(r"^[a-z]([a-z0-9-]{0,40}[a-z0-9])?$")
SNAP_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,40}$")
IMAGE_RE = re.compile(r"^[A-Za-z0-9:_./+-]{1,100}$")

NODE_STATE: Dict[int, dict] = {}
HISTORY: Dict[Any, deque] = defaultdict(lambda: deque(maxlen=HISTORY_LEN))
_prev_cpu: Dict[Any, tuple] = {}
_prev_net: Dict[Any, tuple] = {}
_high_count: Dict[Any, int] = defaultdict(int)


def node_call(node, method, path, body=None, timeout=10):
    if not node.get("url"):
        raise NodeError("node has no URL yet - run the install command on it first")
    try:
        r = requests.request(method, node["url"].rstrip("/") + path, json=body, timeout=timeout, verify=TLS_VERIFY,
                             headers={"Authorization": "Bearer " + (node.get("api_key") or "")})
    except requests.RequestException as e:
        raise NodeError(f"{node['name']} unreachable: {e.__class__.__name__}")
    if r.status_code == 401:
        raise NodeError(f"{node['name']} rejected the token (regenerate it and reinstall the agent)")
    if r.status_code >= 400:
        raise NodeError(f"{node['name']} returned HTTP {r.status_code}")
    return r.json()


def cli(node, tool, argv, timeout=120, check=True, stdin=None):
    """Run `<tool> <argv>` (tool is lxc or docker) on a node. argv is a LIST - no shell, no string splitting anywhere."""
    node = node if isinstance(node, dict) else get_node(node)
    if not node:
        raise NodeError("node not found")
    if node["is_local"]:
        res = agent.cli_run(tool, argv, timeout, stdin)
    else:
        res = node_call(node, "POST", "/v1/exec", {"runtime": tool, "argv": argv, "timeout": timeout, "stdin": stdin}, timeout=timeout + 10)
        x("UPDATE nodes SET api_key_last_used=? WHERE id=?", (now_iso(), node["id"]))
    if check and res["returncode"] != 0:
        msg = (res.get("stderr") or res.get("stdout") or "command failed").strip().splitlines()
        raise NodeError(msg[-1] if msg else "command failed")
    return (res.get("stdout") or "").strip()


def lxc(node, argv, timeout=120, check=True, stdin=None):
    return cli(node, "lxc", argv, timeout, check, stdin)


def dkr(node, argv, timeout=120, check=True, stdin=None):
    return cli(node, "docker", argv, timeout, check, stdin)


def rt(v):
    """Runtime of a VPS row: 'lxc' (system container) or 'docker'."""
    return (v.get("runtime") or "lxc") if isinstance(v, dict) else "lxc"


def vcli(v, argv, timeout=120, check=True):
    """Run a command with the runtime this VPS uses."""
    return cli(v["node_id"], rt(v), argv, timeout, check)


def node_has(node_id, runtime):
    st = NODE_STATE.get(node_id, {})
    rts = st.get("runtimes")
    return runtime == "lxc" if rts is None else bool(rts.get(runtime))


# ---- size parsing / derived stats
_UNITS = {"b": 1, "kb": 1e3, "mb": 1e6, "gb": 1e9, "tb": 1e12, "kib": 2**10, "mib": 2**20, "gib": 2**30, "tib": 2**40}


def parse_bytes(s):
    m = re.match(r"^\s*([\d.]+)\s*([a-zA-Z]*)\s*$", str(s or ""))
    if not m:
        return 0
    return int(float(m.group(1)) * _UNITS.get((m.group(2) or "b").lower(), 0))


def derive_container(nid, c, host, now):
    cores = float(c["cpu_limit"]) if str(c.get("cpu_limit", "")).isdigit() else float(host.get("cpu_cores") or 1)
    mem_total = parse_bytes(c.get("mem_limit")) or int((host.get("ram") or {}).get("total", 0)) * 2**20
    disk_total = parse_bytes(c.get("disk_limit"))
    key = (nid, c["name"])
    cpu = 0.0
    prev = _prev_cpu.get(key)
    if prev and c["status"] == "running" and now > prev[0] and c["cpu_ns"] >= prev[1]:
        cpu = max(0.0, min(100.0, (c["cpu_ns"] - prev[1]) / ((now - prev[0]) * 1e9 * cores) * 100))
    _prev_cpu[key] = (now, c["cpu_ns"])
    rx_rate = tx_rate = 0.0
    pn = _prev_net.get(key)
    if pn and now > pn[0] and c["rx"] >= pn[1] and c["tx"] >= pn[2]:
        rx_rate, tx_rate = (c["rx"] - pn[1]) / (now - pn[0]), (c["tx"] - pn[2]) / (now - pn[0])
    _prev_net[key] = (now, c["rx"], c["tx"])
    pct = lambda a, b: round(a / b * 100, 1) if b else 0.0
    return {"name": c["name"], "status": c["status"], "cpu": round(cpu, 1), "procs": c.get("procs", 0), "ips": c.get("ips", []),
            "ram": {"used_mb": round(c["mem_used"] / 2**20), "total_mb": round(mem_total / 2**20), "pct": pct(c["mem_used"], mem_total)},
            "disk": {"used_gb": round(c["disk_used"] / 2**30, 2), "total_gb": round(disk_total / 2**30, 1), "pct": pct(c["disk_used"], disk_total)},
            "rx": c["rx"], "tx": c["tx"], "rx_rate": round(rx_rate), "tx_rate": round(tx_rate), "snapshots": c.get("snapshots", 0),
            "image": c.get("image", "")}


def derive_docker(nid, c, host, now):
    cores = float(c.get("cpu_cores") or 0) or float(host.get("cpu_cores") or 1)
    mem_total = int(c.get("mem_limit") or 0) or int((host.get("ram") or {}).get("total", 0)) * 2**20
    key = (nid, c["name"])
    rx_rate = tx_rate = 0.0
    pn = _prev_net.get(key)
    if pn and now > pn[0] and c["rx"] >= pn[1] and c["tx"] >= pn[2]:
        rx_rate, tx_rate = (c["rx"] - pn[1]) / (now - pn[0]), (c["tx"] - pn[2]) / (now - pn[0])
    _prev_net[key] = (now, c["rx"], c["tx"])
    cpu = max(0.0, min(100.0, c.get("cpu_pct", 0.0) / cores)) if c["status"] == "running" else 0.0   # docker reports % of ONE core
    return {"name": c["name"], "status": c["status"], "runtime": "docker", "cpu": round(cpu, 1), "procs": c.get("procs", 0), "ips": c.get("ips", []),
            "ram": {"used_mb": round(c["mem_used"] / 2**20), "total_mb": round(mem_total / 2**20), "pct": round(c["mem_used"] / mem_total * 100, 1) if mem_total else 0.0},
            "disk": {"used_gb": 0, "total_gb": 0, "pct": 0.0},
            "rx": c["rx"], "tx": c["tx"], "rx_rate": round(rx_rate), "tx_rate": round(tx_rate), "snapshots": 0, "image": c.get("image", "")}


def poll_node(node):
    nid, t0 = node["id"], time.time()
    prev = NODE_STATE.get(nid, {})
    try:
        snap = agent.snapshot() if node["is_local"] else node_call(node, "GET", "/v1/snapshot", timeout=15)
        host, lx = snap["host"], snap["containers"]
        dk = snap.get("docker") or {"__error__": {"status": "agent too old for Docker", "missing": True}}
        lerr, derr = lx.pop("__error__", None), dk.pop("__error__", None)
        old = prev.get("vps", {})
        vps_state = {}
        if lerr:
            vps_state.update({k: v for k, v in old.items() if v.get("runtime") != "docker"})   # keep last known when LXD hiccups
        else:
            for n, c in lx.items():
                vps_state[n] = derive_container(nid, c, host, t0)
                vps_state[n]["runtime"] = "lxc"
        if derr:
            vps_state.update({k: v for k, v in old.items() if v.get("runtime") == "docker"})
        else:
            for n, c in dk.items():
                vps_state[n] = derive_docker(nid, c, host, t0)
        errs = [f"{label}: {e['status']}" for label, e in (("LXD", lerr), ("Docker", derr)) if e and not e.get("missing")]
        st = {"online": True, "error": None, "lxc_error": "; ".join(errs) or None, "latency_ms": round((time.time() - t0) * 1000),
              "polled_at": t0, "host": host, "vps": vps_state, "agent": snap.get("agent"), "runtimes": snap.get("runtimes"),
              "listed": {"lxc": not lerr, "docker": not derr}}
        HISTORY[("n", nid)].append({"t": round(t0), "cpu": host["cpu"], "ram": host["ram"]["percent"], "disk": host["disk"]["percent"]})
        for n, sv in vps_state.items():
            if sv["status"] == "running" and sv.get("polled", True):
                HISTORY[("c", nid, n)].append({"t": round(t0), "cpu": sv["cpu"], "ram": sv["ram"]["pct"], "rx": sv["rx_rate"], "tx": sv["tx_rate"]})
    except Exception as e:
        st = {"online": False, "error": str(e), "lxc_error": None, "latency_ms": None, "polled_at": t0, "host": prev.get("host"),
              "vps": prev.get("vps", {}), "agent": prev.get("agent"), "runtimes": prev.get("runtimes"), "listed": {"lxc": False, "docker": False}}
    was = prev.get("online")
    NODE_STATE[nid] = st
    if was is not None and was != st["online"]:
        for a in q("SELECT id FROM users WHERE is_admin=1"):
            notify(a["id"], "success" if st["online"] else "error", f"Node {'back online' if st['online'] else 'offline'}",
                   f"{node['name']} is {'reachable again' if st['online'] else 'not responding: ' + str(st['error'])}")
    return st


def sync_vps_status(node):
    """Make the database reflect what LXD / Docker really report (stopped from the CLI, crashes, etc.)."""
    st = NODE_STATE.get(node["id"])
    if not st or not st["online"]:
        return
    for v in q("SELECT id,container_name,status,runtime FROM vps WHERE node_id=?", (node["id"],)):
        if not st["listed"].get(v.get("runtime") or "lxc"):
            continue
        live = st["vps"].get(v["container_name"])
        want = live["status"] if live else "missing"
        if v["status"] != want:
            update_vps(v["id"], status=want, **({"last_stopped": now_iso()} if want == "stopped" and v["status"] == "running" else {}))
            push(f"vps_{v['id']}", "vps_status", {"vps_id": v["id"], "status": want})


def enforce_limits(node):
    if get_setting("auto_suspend", "1") != "1":
        return
    st = NODE_STATE.get(node["id"])
    if not st or not st["online"]:
        return
    cpu_t, ram_t = int(get_setting("cpu_threshold", 90)), int(get_setting("ram_threshold", 95))
    need = max(1, int(float(get_setting("suspend_grace_minutes", 5)) * 60 / POLL_INTERVAL))
    for v in q("SELECT * FROM vps WHERE node_id=? AND status='running' AND suspended=0 AND whitelisted=0", (node["id"],)):
        s = st["vps"].get(v["container_name"])
        key = (node["id"], v["container_name"])
        if s and (s["cpu"] > cpu_t or s["ram"]["pct"] > ram_t):
            _high_count[key] += 1
        else:
            _high_count[key] = 0
        if _high_count[key] >= need:
            _high_count[key] = 0
            reason = f"Auto-suspended: sustained high usage (CPU {s['cpu']:.0f}%, RAM {s['ram']['pct']:.0f}%) for {get_setting('suspend_grace_minutes', 5)} min"
            try:
                suspend_vps(_vps(v), reason, "Auto monitor")
                notify(v["user_id"], "warn", "VPS suspended", f"{v['container_name']} was suspended for sustained high resource usage.")
            except Exception as e:
                logger.error(f"auto-suspend {v['container_name']} failed: {e}")


def backup_database():
    d = BASE_DIR / "backups"
    d.mkdir(exist_ok=True)
    name = f"uiavm_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    src = sqlite3.connect(DB_PATH)
    dst = sqlite3.connect(str(d / name))
    src.backup(dst)
    src.close(); dst.close()
    keep = int(get_setting("backup_retention", 7))
    files = sorted(f for f in os.listdir(d) if f.endswith(".db"))
    for old in files[:-keep] if keep > 0 else []:
        os.remove(d / old)
    return name


_monitor_stop = threading.Event()


def monitor_loop():
    pool = ThreadPoolExecutor(max_workers=8)
    last_backup = time.time()
    last_clean = 0
    last_db_sync = 0
    while not _monitor_stop.is_set():
        t0 = time.time()
        try:
            nodes = get_nodes()
            list(pool.map(poll_node, nodes))
            for n in nodes:
                sync_vps_status(n)
                enforce_limits(n)
            if t0 - last_db_sync > 30:            # persist coarse node facts for the Nodes page + restarts
                last_db_sync = t0
                for n in nodes:
                    st = NODE_STATE.get(n["id"], {})
                    h = st.get("host") or {}
                    kw = {"status": "online" if st.get("online") else "offline"}
                    if st.get("online"):
                        kw.update(last_seen=now_iso(), cpu_cores=h.get("cpu_cores", 0), ram_total=(h.get("ram") or {}).get("total", 0),
                                  disk_total=(h.get("disk") or {}).get("total_gb", 0))
                        if n["is_local"]:
                            kw["agent_version"] = agent.AGENT_VERSION
                        if st.get("runtimes"):
                            kw["lxc_version"] = st["runtimes"].get("lxc") or ""
                            kw["docker_version"] = st["runtimes"].get("docker") or ""
                    update_node(n["id"], **kw)
                refresh_node_counts()
            if get_setting("backup_enabled", "1") == "1" and t0 - last_backup > BACKUP_INTERVAL:
                last_backup = t0
                logger.info(f"database backup: {backup_database()}")
            if t0 - last_clean > 600:
                last_clean = t0
                x("DELETE FROM notifications WHERE expires_at IS NOT NULL AND expires_at<?", (now_iso(),))
                x("DELETE FROM notifications WHERE read=1 AND created_at<?", ((datetime.now() - timedelta(days=30)).isoformat(),))
                x("DELETE FROM activity_logs WHERE created_at<?", ((datetime.now() - timedelta(days=90)).isoformat(),))
        except Exception as e:
            logger.error(f"monitor error: {e}")
        _monitor_stop.wait(max(0.5, POLL_INTERVAL - (time.time() - t0)))


# ---- scheduler
def node_load_score(n):
    st = NODE_STATE.get(n["id"], {})
    h = st.get("host") or {}
    cap = node_vps_count(n["id"]) / max(1, n["total_vps"])
    return cap * 0.6 + (h.get("ram", {}).get("percent", 0) / 100) * 0.25 + (h.get("cpu", 0) / 100) * 0.15


def pick_node(tag=None, runtime="lxc"):
    """Least-loaded online node that still has room, isn't draining and can run the chosen runtime."""
    ok = []
    for n in get_nodes():
        st = NODE_STATE.get(n["id"], {})
        if not st.get("online") or n["drain"] or node_vps_count(n["id"]) >= n["total_vps"] or not node_has(n["id"], runtime):
            continue
        if tag and tag not in n["tags"]:
            continue
        ok.append(n)
    return min(ok, key=node_load_score) if ok else None


# ============================================================================ views of a VPS
def live_vps(v):
    st = NODE_STATE.get(v["node_id"], {})
    return (st.get("vps") or {}).get(v["container_name"])


def node_online(node_id):
    return bool(NODE_STATE.get(node_id, {}).get("online"))


def vps_host(v):
    """What the user should connect to: alias/domain, else the node's public address."""
    n = get_node(v["node_id"]) or {}
    if v.get("ip_alias"):
        return v["ip_alias"]
    if n.get("ip_aliases"):
        return n["ip_aliases"][0]
    if n.get("ip_addresses"):
        return n["ip_addresses"][0]
    if n.get("url"):
        return re.sub(r"^https?://", "", n["url"]).split(":")[0]
    return request.host.split(":")[0] if request else ""


def vps_public(v, with_live=True):
    live = live_vps(v) if with_live else None
    d = {k: v[k] for k in ("id", "container_name", "hostname", "ram", "cpu", "storage", "os_version", "status", "suspended",
                           "whitelisted", "node_id", "node_name", "owner", "user_id", "created_at", "last_started", "notes", "container_profile")}
    d["status_live"] = (live or {}).get("status", d["status"])
    d["live"] = live
    d["runtime"] = rt(v)
    d["runtime_label"] = RUNTIME_LABEL[rt(v)]
    d["os_label"] = os_label(v["os_version"], rt(v))
    d["os_icon"] = os_icon(v["os_version"], rt(v))
    d["node_online"] = node_online(v["node_id"])
    return d


def os_label(val, runtime="lxc"):
    pool = DOCKER_IMAGES if runtime == "docker" else OS_OPTIONS
    return next((o["label"] for o in pool if o["value"] == val), val or "Custom")


def os_icon(val, runtime="lxc"):
    pool = DOCKER_IMAGES if runtime == "docker" else OS_OPTIONS
    return next((o["icon"] for o in pool if o["value"] == val), "docker" if runtime == "docker" else "linux")


def docker_keepalive(image):
    """Plain OS images exit immediately unless we give them something to run; app images (nginx...) keep their own command."""
    return next((o["keepalive"] for o in DOCKER_IMAGES if o["value"] == image), True)


# ============================================================================ ports
def user_quota(uid):
    r = q("SELECT allocated_ports FROM port_allocations WHERE user_id=?", (uid,), one=True)
    return r["allocated_ports"] if r else int(get_setting("default_port_quota", 5))


def user_ports_used(uid):
    return q("SELECT COUNT(*) n FROM port_forwards WHERE user_id=?", (uid,), one=True)["n"]


def free_host_port(node_id):
    used = {r["host_port"] for r in q("SELECT host_port FROM port_forwards WHERE vps_container IN (SELECT container_name FROM vps WHERE node_id=?)", (node_id,))}
    import random
    for _ in range(200):
        p = random.randint(20000, 50000)
        if p not in used:
            return p
    return None


def proxy_args(name, host_port, vps_port, proto):
    return ["config", "device", "add", name, f"{proto}_proxy_{host_port}", "proxy",
            f"listen={proto}:0.0.0.0:{host_port}", f"connect={proto}:127.0.0.1:{vps_port}"]


def fwd(node, op, host_port, container=None, port=None):
    """Docker VPS: ask the node's built-in TCP forwarder (Docker can't publish ports on a running container)."""
    node = node if isinstance(node, dict) else get_node(node)
    if node["is_local"]:
        res = agent.forward_op(op, host_port, container, port)
    else:
        res = node_call(node, "POST", "/v1/forward", {"op": op, "host_port": host_port, "container": container, "port": port}, timeout=15)
    if not res.get("ok"):
        raise NodeError(res.get("error") or "port forward failed")


def add_forward(user_id, v, vps_port, protocol="tcp", description=""):
    docker = rt(v) == "docker"
    protos = ["tcp"] if docker else ([p for p in ("tcp", "udp") if p in protocol.split(",")] or ["tcp"])
    node = get_node(v["node_id"])
    last_err = None
    for _ in range(5):
        hp = free_host_port(v["node_id"])
        if not hp:
            raise NodeError("no free host ports on this node")
        done = []
        try:
            if docker:
                fwd(node, "add", hp, v["container_name"], vps_port)
            else:
                for p in protos:
                    lxc(node, proxy_args(v["container_name"], hp, vps_port, p))
                    done.append(p)
            fid = x("INSERT INTO port_forwards (user_id,vps_container,vps_port,host_port,protocol,description,created_at,last_used) VALUES (?,?,?,?,?,?,?,?)",
                    (user_id, v["container_name"], vps_port, hp, ",".join(protos), description[:80], now_iso(), now_iso()))
            return fid, hp
        except NodeError as e:
            last_err = e
            for p in done:
                try: lxc(node, ["config", "device", "remove", v["container_name"], f"{p}_proxy_{hp}"], check=False)
                except Exception: pass
    raise last_err or NodeError("could not create forward")


def remove_forward(fid):
    f = q("SELECT * FROM port_forwards WHERE id=?", (fid,), one=True)
    if not f:
        return False
    v = q("SELECT node_id, runtime FROM vps WHERE container_name=?", (f["vps_container"],), one=True)
    if v:
        try:
            if rt(v) == "docker":
                fwd(v["node_id"], "remove", f["host_port"])
            else:
                for p in f["protocol"].split(","):
                    lxc(v["node_id"], ["config", "device", "remove", f["vps_container"], f"{p}_proxy_{f['host_port']}"], check=False)
        except Exception as e:
            logger.warning(f"remove forward {f['host_port']}: {e}")
    x("DELETE FROM port_forwards WHERE id=?", (fid,))
    return True


def ensure_forwards(v):
    """Idempotent: re-add any forward the container lost (e.g. after a reinstall)."""
    node = get_node(v["node_id"])
    rows = q("SELECT * FROM port_forwards WHERE vps_container=?", (v["container_name"],))
    if rt(v) == "docker":
        for f in rows:
            try: fwd(node, "add", f["host_port"], v["container_name"], f["vps_port"])
            except NodeError as e: logger.warning(f"re-add forward {f['host_port']}: {e}")
        return
    have = lxc(node, ["config", "device", "list", v["container_name"]], check=False)
    for f in rows:
        for p in f["protocol"].split(","):
            if f"{p}_proxy_{f['host_port']}" not in have:
                try: lxc(node, proxy_args(v["container_name"], f["host_port"], f["vps_port"], p))
                except NodeError as e: logger.warning(f"re-add forward {f['host_port']}: {e}")


# ============================================================================ jobs (long operations with live progress)
JOBS: Dict[str, dict] = {}


class Job:
    def __init__(self, user_id, title):
        self.id = secrets.token_hex(6)
        self.d = {"id": self.id, "user_id": user_id, "title": title, "status": "running", "steps": [], "error": None,
                  "result": {}, "created": time.time()}
        JOBS[self.id] = self.d
        for old in sorted(JOBS, key=lambda k: JOBS[k]["created"])[:-200]:
            JOBS.pop(old, None)

    def step(self, msg):
        self.d["steps"].append(msg)
        push(f"user_{self.d['user_id']}", "job", {k: self.d[k] for k in ("id", "title", "status", "steps", "error", "result")})

    def finish(self, error=None, **result):
        self.d["status"], self.d["error"] = ("error" if error else "done"), error
        self.d["result"] = result
        push(f"user_{self.d['user_id']}", "job", {k: self.d[k] for k in ("id", "title", "status", "steps", "error", "result")})


def start_job(user_id, title, fn, *args):
    job = Job(user_id, title)

    def runner():
        try:
            fn(job, *args)
        except Exception as e:
            logger.error(f"job '{title}' failed: {e}")
            job.finish(error=str(e))
    threading.Thread(target=runner, daemon=True).start()
    return job.id


# ============================================================================ VPS operations
def apply_profile(node, name, profile):
    cfg = {}
    if profile in ("docker", "privileged"):
        cfg["security.nesting"] = "true"
    if profile == "docker":
        cfg.update({"security.syscalls.intercept.mknod": "true", "security.syscalls.intercept.setxattr": "true",
                    "linux.kernel_modules": "overlay,br_netfilter"})
    if profile == "privileged":
        cfg.update({"security.privileged": "true", "security.syscalls.intercept.mknod": "true",
                    "security.syscalls.intercept.setxattr": "true",
                    "linux.kernel_modules": "overlay,loop,nf_nat,ip_tables,ip6_tables,netlink_diag,br_netfilter",
                    "raw.lxc": "lxc.apparmor.profile=unconfined\nlxc.cap.drop=\nlxc.cgroup.devices.allow=a\nlxc.cgroup2.devices.allow=a\n"
                               "lxc.mount.auto=proc:rw sys:rw cgroup:rw\nlxc.mount.entry=/dev/fuse dev/fuse none bind,create=file 0 0\n"})
    for k, v in cfg.items():
        lxc(node, ["config", "set", name, k, v])
    if profile in ("docker", "privileged"):
        lxc(node, ["config", "device", "add", name, "fuse", "unix-char", "path=/dev/fuse"], check=False)


BOOTSTRAP = ("mkdir -p /etc/sysctl.d && printf 'net.ipv4.ip_unprivileged_port_start=0\\nnet.ipv4.ping_group_range=0 2147483647\\n"
             "fs.inotify.max_user_watches=524288\\n' > /etc/sysctl.d/99-uiavm.conf; sysctl -p /etc/sysctl.d/99-uiavm.conf >/dev/null 2>&1; "
             "if command -v apk >/dev/null; then apk update && apk add curl wget net-tools htop; "
             "elif command -v apt-get >/dev/null; then apt-get update -y && apt-get install -y curl wget net-tools htop; "
             "elif command -v dnf >/dev/null; then dnf install -y curl wget net-tools htop; fi; true")


def wait_running(node, name, tries=30):
    for _ in range(tries):
        if "running" in lxc(node, ["info", name], check=False).lower().split("status:")[-1][:12]:
            time.sleep(3)  # let init + networking settle
            return True
        time.sleep(1)
    return False


def build_container(job, node, name, image, ram_gb, cpu, disk_gb, profile, ip_address=None, bootstrap=True):
    job.step(f"Creating {name} from {image} on {node['name']}")
    lxc(node, ["init", image, name, "-s", STORAGE_POOL], timeout=900)
    try:
        job.step(f"Applying limits: {ram_gb} GB RAM, {cpu} CPU, {disk_gb} GB disk")
        lxc(node, ["config", "set", name, "limits.memory", f"{int(ram_gb * 1024)}MiB"])
        lxc(node, ["config", "set", name, "limits.cpu", str(cpu)])
        try:
            lxc(node, ["config", "device", "override", name, "root", f"size={disk_gb}GiB"])
        except NodeError:
            lxc(node, ["config", "device", "set", name, "root", f"size={disk_gb}GiB"])
        if ip_address:
            job.step(f"Reserving address {ip_address}")
            lxc(node, ["config", "device", "override", name, "eth0", f"ipv4.address={ip_address}"])
        job.step(f"Applying '{profile}' profile")
        apply_profile(node, name, profile)
        job.step("Starting container")
        lxc(node, ["start", name])
        if bootstrap:
            job.step("Waiting for boot and installing base packages")
            if wait_running(node, name):
                lxc(node, ["exec", name, "--", "sh", "-c", BOOTSTRAP], timeout=300, check=False)
    except Exception:
        try: lxc(node, ["delete", name, "--force"], check=False)
        except Exception: pass
        raise


def docker_args(name, image, ram_mb, cpu, privileged=False, keepalive=True, storage_gb=None):
    a = ["run", "-d", "--name", name, "--hostname", name, "--restart", "unless-stopped", "--init", "--label", "uiavm=1",
         "--memory", f"{ram_mb}m", "--memory-swap", f"{ram_mb}m", "--cpus", str(cpu), "--pids-limit", "4096"]
    if storage_gb:
        a += ["--storage-opt", f"size={storage_gb}G"]
    if privileged:
        a.append("--privileged")
    a.append(image)
    if keepalive:
        a += ["tail", "-f", "/dev/null"]
    return a


def build_docker(job, node, name, image, ram_gb, cpu, disk_gb, privileged, keepalive):
    """Pull + run a Docker container as a VPS. Returns True when the disk limit is enforced."""
    job.step(f"Pulling {image} on {node['name']}")
    dkr(node, ["pull", image], timeout=900)
    job.step(f"Starting container: {ram_gb} GB RAM, {cpu} CPU")
    ram_mb, enforced = int(ram_gb * 1024), True
    try:
        try:
            dkr(node, docker_args(name, image, ram_mb, cpu, privileged, keepalive, disk_gb), timeout=120)
        except NodeError as e:
            if not any(k in str(e).lower() for k in ("storage-opt", "quota", "pquota")):
                raise
            dkr(node, ["rm", "-f", name], check=False)
            enforced = False
            job.step("This Docker setup can't enforce disk quotas, continuing without a disk limit")
            dkr(node, docker_args(name, image, ram_mb, cpu, privileged, keepalive, None), timeout=120)
    except Exception:
        try: dkr(node, ["rm", "-f", name], check=False)
        except Exception: pass
        raise
    return enforced


def provision_vps(job, admin_id, p):
    node = get_node(p["node_id"])
    runtime = p.get("runtime", "lxc")
    if not node_online(node["id"]):
        raise NodeError(f"{node['name']} is offline")
    meta = {}
    if runtime == "docker":
        meta["disk_enforced"] = build_docker(job, node, p["name"], p["image"], p["ram"], p["cpu"], p["disk"], p["profile"] == "privileged", p.get("keepalive", True))
        meta["keepalive"] = p.get("keepalive", True)
    else:
        build_container(job, node, p["name"], p["image"], p["ram"], p["cpu"], p["disk"], p["profile"], p.get("ip_address"),
                        get_setting("bootstrap_packages", "1") == "1")
    vid = x("""INSERT INTO vps (user_id,node_id,container_name,hostname,ram,cpu,storage,config,os_version,status,created_at,updated_at,
               ip_address,ip_alias,container_profile,image_label,runtime,metadata) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (p["user_id"], node["id"], p["name"], p["name"], f"{p['ram']}GB", str(p["cpu"]), f"{p['disk']}GB",
             f"{p['ram']}GB RAM / {p['cpu']} CPU / {p['disk']}GB Disk", p["image"], "running", now_iso(), now_iso(),
             p.get("ip_address"), p.get("ip_alias"), p["profile"], os_label(p["image"], runtime), runtime, json.dumps(meta)))
    update_vps(vid, last_started=now_iso())
    refresh_node_counts()
    log_activity(admin_id, "create_vps", "vps", vid, {"container": p["name"], "node": node["name"], "runtime": runtime})
    notify(p["user_id"], "success", "VPS ready", f"{p['name']} ({RUNTIME_LABEL[runtime]}) is online on {node['name']}.")
    job.step("Done")
    job.finish(vps_id=vid)


def reinstall_vps(job, v, image, actor_id):
    node = get_node(v["node_id"])
    name = v["container_name"]
    ram, cpu, disk = [int(re.sub(r"\D", "", s_) or 1) for s_ in (v["ram"], v["cpu"], v["storage"])]
    job.step("Stopping and removing the old container")
    if rt(v) == "docker":
        dkr(node, ["rm", "-f", name], check=False)
        build_docker(job, node, name, image, ram, cpu, disk, v.get("container_profile") == "privileged", docker_keepalive(image))
    else:
        lxc(node, ["delete", name, "--force"], check=False)
        build_container(job, node, name, image, ram, cpu, disk, v.get("container_profile") or "docker", v.get("ip_address"),
                        get_setting("bootstrap_packages", "1") == "1")
    job.step("Restoring port forwards")
    ensure_forwards(v)
    update_vps(v["id"], os_version=image, image_label=os_label(image, rt(v)), status="running", last_started=now_iso())
    log_activity(actor_id, "reinstall_vps", "vps", v["id"], {"image": image})
    notify(v["user_id"], "success", "Reinstall complete", f"{name} now runs {os_label(image, rt(v))}.")
    job.finish(vps_id=v["id"])


def power(v, action, actor_id=None):
    node, name = get_node(v["node_id"]), v["container_name"]
    docker = rt(v) == "docker"
    if action == "start":
        (dkr(node, ["start", name]) if docker else lxc(node, ["start", name])); ensure_forwards(v)
        update_vps(v["id"], status="running", last_started=now_iso())
    elif action == "stop":
        if docker:
            dkr(node, ["stop", "-t", "30", name], timeout=90)
        else:
            try: lxc(node, ["stop", name, "--timeout", "30"], timeout=60)
            except NodeError: lxc(node, ["stop", name, "--force"])
        update_vps(v["id"], status="stopped", last_stopped=now_iso())
    elif action == "restart":
        (dkr(node, ["restart", "-t", "30", name], timeout=90) if docker else lxc(node, ["restart", name, "--force"], timeout=90)); ensure_forwards(v)
        update_vps(v["id"], status="running", last_started=now_iso())
    elif action == "freeze":
        (dkr(node, ["pause", name]) if docker else lxc(node, ["pause", name])); update_vps(v["id"], status="frozen")
    elif action == "unfreeze":
        (dkr(node, ["unpause", name]) if docker else lxc(node, ["start", name])); update_vps(v["id"], status="running")
    else:
        raise NodeError("unknown action")
    push(f"vps_{v['id']}", "vps_status", {"vps_id": v["id"], "status": get_vps(v["id"])["status"]})
    log_activity(actor_id, f"{action}_vps", "vps", v["id"])


def suspend_vps(v, reason, by):
    try:
        vcli(v, ["stop", "-t", "5", v["container_name"]] if rt(v) == "docker" else ["stop", v["container_name"], "--force"], check=False)
    except Exception:
        pass
    hist = v["suspension_history"] + [{"time": now_iso(), "reason": reason, "by": by}]
    update_vps(v["id"], suspended=1, status="stopped", suspended_reason=reason, suspension_history=hist, last_stopped=now_iso())
    log_activity(None, "suspend_vps", "vps", v["id"], {"reason": reason, "by": by})


def delete_vps_full(v, actor_id):
    node = get_node(v["node_id"])
    if rt(v) == "docker":
        for f in q("SELECT host_port FROM port_forwards WHERE vps_container=?", (v["container_name"],)):
            try: fwd(node, "remove", f["host_port"])
            except Exception: pass
        for sn in list_snapshots(v):
            dkr(node, ["rmi", f"{snap_repo(v)}:{sn['name']}"], check=False)
        dkr(node, ["rm", "-f", v["container_name"]], check=False)
    else:
        lxc(node, ["delete", v["container_name"], "--force"], check=False)
    x("DELETE FROM port_forwards WHERE vps_container=?", (v["container_name"],))
    x("DELETE FROM vps WHERE id=?", (v["id"],))
    refresh_node_counts()
    log_activity(actor_id, "delete_vps", "vps", v["id"], {"container": v["container_name"]})
    notify(v["user_id"], "info", "VPS deleted", f"{v['container_name']} was deleted.")


def snap_repo(v):
    return f"uiavm-snap/{v['container_name']}"


def list_snapshots(v):
    if rt(v) == "docker":
        out = vcli(v, ["images", snap_repo(v), "--format", "{{json .}}"], check=False)
        res = []
        for line in out.splitlines():
            try:
                d = json.loads(line)
                res.append({"name": d["Tag"], "created": (d.get("CreatedAt") or "").split(" +")[0].replace(" ", "T"), "stateful": False})
            except Exception:
                pass
        return res
    out = lxc(v["node_id"], ["query", f"/1.0/instances/{v['container_name']}/snapshots?recursion=1"], check=False)
    try:
        return [{"name": s_["name"].split("/")[-1], "created": s_.get("created_at"), "stateful": s_.get("stateful", False)} for s_ in json.loads(out or "[]")]
    except Exception:
        return []


def snapshot_create(v, name):
    if rt(v) == "docker":
        dkr(v["node_id"], ["commit", v["container_name"], f"{snap_repo(v)}:{name}"], timeout=600)   # filesystem snapshot (not volumes)
    else:
        lxc(v["node_id"], ["snapshot", v["container_name"], name], timeout=300)


def snapshot_restore(v, name):
    if rt(v) == "docker":
        node, cn = get_node(v["node_id"]), v["container_name"]
        ram, cpu = [int(re.sub(r"\D", "", s_) or 1) for s_ in (v["ram"], v["cpu"])]
        dkr(node, ["rm", "-f", cn], check=False)       # the snapshot image keeps the original command, so no keepalive needed
        dkr(node, docker_args(cn, f"{snap_repo(v)}:{name}", ram * 1024, cpu, v.get("container_profile") == "privileged", False), timeout=120)
        update_vps(v["id"], status="running", last_started=now_iso())
    else:
        lxc(v["node_id"], ["restore", v["container_name"], name], timeout=300)


def snapshot_delete(v, name):
    if rt(v) == "docker":
        dkr(v["node_id"], ["rmi", f"{snap_repo(v)}:{name}"])
    else:
        lxc(v["node_id"], ["delete", f"{v['container_name']}/{name}"], timeout=120)


# ============================================================================ template context
THEMES = {"ion": "Ion", "plasma": "Plasma", "solar": "Solar", "aurora": "Aurora"}


def ago(value):
    if not value:
        return "never"
    try:
        dt = datetime.fromisoformat(value) if isinstance(value, str) else value
    except Exception:
        return str(value)
    s = int((datetime.now() - dt).total_seconds())
    if s < 0: s = 0
    for secs, label in ((86400 * 365, "y"), (86400 * 30, "mo"), (86400, "d"), (3600, "h"), (60, "m")):
        if s >= secs:
            return f"{s // secs}{label} ago"
    return "just now" if s < 10 else f"{s}s ago"


def fmt_bytes(n):
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024


app.jinja_env.filters.update(ago=ago, bytes=fmt_bytes,
                             dt=lambda v: (datetime.fromisoformat(v).strftime("%d %b %Y, %H:%M") if v else "-"))


USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def check_identity(username=None, email=None, exclude_id=None):
    """Returns an error string, or None when username/email are valid and free."""
    if username is not None:
        if not USERNAME_RE.match(username):
            return "Username must be 3-32 characters: letters, numbers, dots, dashes, underscores."
        r = q("SELECT id FROM users WHERE lower(username)=lower(?)", (username,), one=True)
        if r and r["id"] != exclude_id:
            return "That username is already taken."
    if email is not None:
        if not EMAIL_RE.match(email):
            return "Enter a valid email address."
        r = q("SELECT id FROM users WHERE lower(email)=lower(?)", (email,), one=True)
        if r and r["id"] != exclude_id:
            return "That email is already in use."
    return None


@app.context_processor
def inject():
    d = {"panel": get_setting("site_name", PANEL_NAME), "version": PANEL_VERSION, "author": PANEL_AUTHOR, "csrf_token": csrf_token,
         "themes": THEMES, "os_options": OS_OPTIONS, "docker_images": DOCKER_IMAGES, "footer": get_setting("footer_text", ""), "socketio_on": SOCKETIO}
    if current_user.is_authenticated:
        d["unread"] = unread_count(current_user.id)
        d["impersonating"] = bool(session.get("impersonator"))
    return d


def ok(**kw):
    return jsonify(success=True, **kw)


def fail(msg, code=400):
    return jsonify(success=False, error=msg), code


def body():
    return request.get_json(silent=True) or request.form.to_dict() or {}


def vps_route(f):
    """Loads the VPS, checks access, passes it in. Works for pages and JSON routes alike."""
    @wraps(f)
    @login_required
    def w(vps_id, *a, **k):
        v = get_vps(vps_id)
        if not can_access_vps(current_user, v):
            if request.path.startswith("/api/") or request.method == "POST":
                return fail("VPS not found or access denied", 404)
            abort(404)
        return f(v, *a, **k)
    return w


def usable(v):
    """Owners can't operate a suspended VPS; admins always can."""
    return current_user.is_admin or not v["suspended"]


# ============================================================================ auth
def safe_next(url):
    return url if url and url.startswith("/") and not url.startswith("//") else None


@app.route("/")
def index():
    return redirect(url_for("dashboard" if current_user.is_authenticated else "login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        ip = request.remote_addr or "?"
        if rate_limited(ip):
            flash("Too many attempts. Wait a few minutes and try again.", "error")
            return render_template("login.html", tab="login", registration=get_setting("registration_enabled") == "1"), 429
        ident = request.form.get("username", "").strip()
        u = User.by("username", ident) or User.by("email", ident)
        if u and check_password_hash(u.password_hash, request.form.get("password", "")):
            if u.two_factor_enabled:
                session["pre_2fa"] = {"uid": u.id, "next": safe_next(request.args.get("next")), "t": time.time()}
                return redirect(url_for("twofa"))
            return finish_login(u)
        rate_hit(ip)
        log_activity(None, "login_failed", "user", ident[:40])
        flash("Wrong username or password.", "error")
    return render_template("login.html", tab="login", registration=get_setting("registration_enabled") == "1")


def finish_login(u, nxt=None):
    session.clear()
    login_user(u, remember=False)
    session.permanent = True
    x("UPDATE users SET last_login=?, last_active=? WHERE id=?", (now_iso(), now_iso(), u.id))
    log_activity(u.id, "login", "user", u.id)
    return redirect(nxt or safe_next(request.args.get("next")) or url_for("dashboard"))


@app.route("/2fa", methods=["GET", "POST"])
def twofa():
    pre = session.get("pre_2fa")
    if not pre or time.time() - pre["t"] > 300:
        return redirect(url_for("login"))
    u = User.by("id", pre["uid"])
    if request.method == "POST":
        if rate_limited("2fa" + str(u.id), 6, 300):
            flash("Too many attempts. Wait a few minutes.", "error")
        elif totp_verify(u.two_factor_secret, request.form.get("code")):
            return finish_login(u, pre.get("next"))
        else:
            rate_hit("2fa" + str(u.id))
            flash("That code didn't match. Codes change every 30 seconds.", "error")
    return render_template("twofa.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if get_setting("registration_enabled") != "1":
        flash("Registration is closed. Ask an administrator for an account.", "warn")
        return redirect(url_for("login"))
    if request.method == "POST":
        f = request.form
        name, email, pw = f.get("username", "").strip(), f.get("email", "").strip().lower(), f.get("password", "")
        err = check_identity(name, email)
        if not err and len(pw) < 8:
            err = "Password needs at least 8 characters."
        if not err and pw != f.get("confirm", pw):
            err = "The two passwords don't match."
        if err:
            flash(err, "error")
        else:
            uid = x("INSERT INTO users (username,email,password_hash,created_at,api_key) VALUES (?,?,?,?,?)",
                    (name, email, generate_password_hash(pw), now_iso(), new_token(48)))
            x("INSERT INTO port_allocations (user_id,allocated_ports,updated_at) VALUES (?,?,?)", (uid, int(get_setting("default_port_quota", 5)), now_iso()))
            log_activity(uid, "register", "user", uid)
            for a in q("SELECT id FROM users WHERE is_admin=1"):
                notify(a["id"], "info", "New account", f"{name} just registered.")
            flash("Account created. Sign in to continue.", "success")
            return redirect(url_for("login"))
    return render_template("login.html", tab="register", registration=True)


@app.route("/logout", methods=["POST"])
@login_required
def logout():
    log_activity(current_user.id, "logout", "user", current_user.id)
    logout_user()
    session.clear()
    return redirect(url_for("login"))


# ============================================================================ live data
def node_card(n):
    st = NODE_STATE.get(n["id"], {})
    h = st.get("host") or {}
    online = bool(st.get("online"))
    pending = not n["is_local"] and not n.get("url")
    return {"id": n["id"], "name": n["name"], "location": n["location"], "is_local": bool(n["is_local"]), "tags": n["tags"],
            "online": online, "drain": bool(n["drain"]), "pending": pending,
            "state": "pending" if pending else ("offline" if not online else ("draining" if n["drain"] else "online")),
            "error": st.get("error") or st.get("lxc_error"), "latency_ms": st.get("latency_ms"),
            "cpu": h.get("cpu", 0), "cores": h.get("cpu_cores") or n.get("cpu_cores") or 0, "load": h.get("load"),
            "ram": h.get("ram") or {"total": n.get("ram_total", 0), "used": 0, "percent": 0},
            "disk": h.get("disk") or {"total_gb": n.get("disk_total", 0), "used_gb": 0, "percent": 0},
            "uptime_s": h.get("uptime_s"), "kernel": h.get("kernel"), "hostname": h.get("hostname"),
            "vps_count": node_vps_count(n["id"]), "total_vps": n["total_vps"], "url": n.get("url"),
            "agent_version": n.get("agent_version"), "lxc_version": n.get("lxc_version"), "docker_version": n.get("docker_version"), "last_seen": n.get("last_seen"),
            "runtimes": st.get("runtimes") or {"lxc": n.get("lxc_version") or None, "docker": n.get("docker_version") or None},
            "ip_addresses": n["ip_addresses"], "ip_aliases": n["ip_aliases"],
            "history": [p["cpu"] for p in list(HISTORY[("n", n["id"])])[-40:]]}


def cluster_totals(cards):
    on = [c for c in cards if c["online"]]
    cores = sum(c["cores"] for c in on) or 1
    ram_t, ram_u = sum(c["ram"].get("total", 0) for c in on), sum(c["ram"].get("used", 0) for c in on)
    d_t, d_u = sum(c["disk"].get("total_gb", 0) for c in on), sum(c["disk"].get("used_gb", 0) for c in on)
    return {"nodes": len(cards), "online": len(on), "cpu": round(sum(c["cpu"] * c["cores"] for c in on) / cores, 1),
            "ram_pct": round(ram_u / ram_t * 100, 1) if ram_t else 0, "ram_used_gb": round(ram_u / 1024, 1), "ram_total_gb": round(ram_t / 1024, 1),
            "disk_pct": round(d_u / d_t * 100, 1) if d_t else 0, "disk_used_gb": round(d_u), "disk_total_gb": round(d_t), "cores": cores if on else 0}


def live_payload(user):
    vps = get_all_vps() if user.is_admin else get_vps_for_user(user.id)
    rows = []
    for v in vps:
        lv = live_vps(v) or {}
        rows.append({"id": v["id"], "status": lv.get("status") or v["status"], "cpu": lv.get("cpu", 0), "ram_pct": (lv.get("ram") or {}).get("pct", 0),
                     "ram_used": (lv.get("ram") or {}).get("used_mb", 0), "disk_pct": (lv.get("disk") or {}).get("pct", 0),
                     "rx_rate": lv.get("rx_rate", 0), "tx_rate": lv.get("tx_rate", 0), "procs": lv.get("procs", 0), "suspended": v["suspended"],
                     "node_online": node_online(v["node_id"]), "ips": lv.get("ips", [])})
    out = {"t": time.time(), "unread": unread_count(user.id), "vps": rows,
           "summary": {"total": len(rows), "running": sum(r["status"] == "running" for r in rows),
                       "stopped": sum(r["status"] == "stopped" for r in rows), "suspended": sum(r["suspended"] for r in rows),
                       "frozen": sum(r["status"] == "frozen" for r in rows)}}
    if user.is_admin:
        cards = [node_card(n) for n in get_nodes()]
        out["nodes"], out["cluster"] = cards, cluster_totals(cards)
        out["cluster"]["history"] = [p["cpu"] for p in HISTORY[("n", cards[0]["id"])]] if cards else []
    return out


@app.route("/api/live")
@login_required
def api_live():
    return jsonify(live_payload(current_user))


@app.route("/api/vps/<int:vps_id>/live")
@vps_route
def api_vps_live(v):
    lv = live_vps(v) or {}
    return jsonify(status=lv.get("status") or v["status"], live=lv, node_online=node_online(v["node_id"]),
                   history=list(HISTORY[("c", v["node_id"], v["container_name"])]))


@app.route("/api/jobs/<jid>")
@login_required
def api_job(jid):
    j = JOBS.get(jid)
    if not j or (j["user_id"] != current_user.id and not current_user.is_admin):
        return fail("job not found", 404)
    return jsonify(j)


@app.route("/api/search")
@login_required
def api_search():
    term = request.args.get("q", "").strip().lower()
    res = []
    pages = [("Dashboard", "dashboard"), ("My VPS", "vps_list"), ("Port forwards", "ports"), ("Notifications", "notifications"), ("Profile and security", "profile")]
    if current_user.is_admin:
        pages += [("Nodes", "admin_nodes"), ("Users", "admin_users"), ("All VPS", "admin_vps"), ("Create VPS", "admin_vps_create"),
                  ("Settings", "admin_settings"), ("Activity log", "admin_logs")]
    for label, ep in pages:
        if term in label.lower():
            res.append({"kind": "page", "title": label, "sub": "Go to page", "url": url_for(ep)})
    vs = get_all_vps() if current_user.is_admin else get_vps_for_user(current_user.id)
    for v in vs:
        if term and (term in v["container_name"].lower() or term in (v.get("owner") or "").lower()):
            res.append({"kind": "vps", "title": v["container_name"], "sub": f"{v['status']} on {v['node_name']}", "url": url_for("vps_detail", vps_id=v["id"])})
    if current_user.is_admin and term:
        for n in get_nodes():
            if term in n["name"].lower():
                res.append({"kind": "node", "title": n["name"], "sub": n["location"] or "node", "url": url_for("admin_nodes") + f"#node-{n['id']}"})
        for u in q("SELECT id,username,email FROM users WHERE username LIKE ? OR email LIKE ? LIMIT 5", (f"%{term}%", f"%{term}%")):
            res.append({"kind": "user", "title": u["username"], "sub": u["email"], "url": url_for("admin_users")})
    return jsonify(res[:14])


# ============================================================================ dashboard + VPS pages
@app.route("/dashboard")
@login_required
def dashboard():
    live = live_payload(current_user)
    vps = get_all_vps() if current_user.is_admin else get_vps_for_user(current_user.id)
    recent = q("SELECT a.*, u.username FROM activity_logs a LEFT JOIN users u ON u.id=a.user_id " +
               ("" if current_user.is_admin else "WHERE a.user_id=? ") + "ORDER BY a.id DESC LIMIT 8",
               () if current_user.is_admin else (current_user.id,))
    return render_template("dashboard.html", live=live, vps=[vps_public(v) for v in vps][:8], recent=recent,
                           users_count=q("SELECT COUNT(*) n FROM users", one=True)["n"] if current_user.is_admin else None,
                           ports_used=user_ports_used(current_user.id), ports_quota=user_quota(current_user.id))


@app.route("/vps")
@login_required
def vps_list():
    vps = get_vps_for_user(current_user.id) if not (current_user.is_admin and request.args.get("all")) else get_all_vps()
    return render_template("vps_list.html", vps=[vps_public(v) for v in vps], show_all=bool(request.args.get("all")))


@app.route("/vps/<int:vps_id>")
@vps_route
def vps_detail(v):
    forwards = q("SELECT * FROM port_forwards WHERE vps_container=? ORDER BY created_at DESC", (v["container_name"],))
    ssh = next((f for f in forwards if f["vps_port"] == 22), None)
    shared = [User.by("id", int(i)) for i in v["shared_with"] if str(i).isdigit()]
    return render_template("vps_detail.html", v=vps_public(v), raw=v, forwards=forwards, host=vps_host(v), ssh=ssh,
                           shared=[{"id": s.id, "username": s.username} for s in shared if s],
                           is_owner=(v["user_id"] == current_user.id or current_user.is_admin),
                           quota=(user_ports_used(v["user_id"]), user_quota(v["user_id"])),
                           history=list(HISTORY[("c", v["node_id"], v["container_name"])]),
                           max_snapshots=int(get_setting("max_snapshots", 5)))


@app.route("/vps/<int:vps_id>/power/<action>", methods=["POST"])
@vps_route
def vps_power(v, action):
    if not usable(v):
        return fail("This VPS is suspended. Contact an administrator.", 403)
    if action not in ("start", "stop", "restart", "freeze", "unfreeze"):
        return fail("Unknown action")
    if not node_online(v["node_id"]):
        return fail("The node hosting this VPS is offline.", 503)
    try:
        power(v, action, current_user.id)
        return ok(status=get_vps(v["id"])["status"])
    except NodeError as e:
        notify(current_user.id, "error", f"Couldn't {action} {v['container_name']}", str(e))
        return fail(str(e), 500)


@app.route("/vps/<int:vps_id>/settings", methods=["POST"])
@vps_route
def vps_settings(v):
    b = body()
    kw = {}
    if "notes" in b:
        kw["notes"] = str(b["notes"])[:2000]
    if "hostname" in b and re.match(r"^[A-Za-z0-9.-]{1,63}$", str(b["hostname"])):
        kw["hostname"] = b["hostname"]
    update_vps(v["id"], **kw)
    return ok()


@app.route("/vps/<int:vps_id>/snapshots")
@vps_route
def vps_snapshots(v):
    return jsonify(snapshots=list_snapshots(v), max=int(get_setting("max_snapshots", 5)))


@app.route("/vps/<int:vps_id>/snapshots/create", methods=["POST"])
@vps_route
def vps_snapshot_create(v):
    if not usable(v):
        return fail("VPS is suspended", 403)
    name = str(body().get("name") or datetime.now().strftime("snap-%Y%m%d-%H%M%S"))
    if not SNAP_RE.match(name):
        return fail("Snapshot names use letters, numbers, dots, dashes and underscores.")
    if len(list_snapshots(v)) >= int(get_setting("max_snapshots", 5)):
        return fail(f"Snapshot limit reached ({get_setting('max_snapshots', 5)}). Delete one first.")
    try:
        snapshot_create(v, name)
    except NodeError as e:
        return fail(str(e), 500)
    log_activity(current_user.id, "snapshot_create", "vps", v["id"], {"name": name})
    return ok(name=name)


@app.route("/vps/<int:vps_id>/snapshots/<name>/<op>", methods=["POST"])
@vps_route
def vps_snapshot_op(v, name, op):
    if not usable(v) or not SNAP_RE.match(name) or op not in ("restore", "delete"):
        return fail("Not allowed", 403)
    try:
        snapshot_restore(v, name) if op == "restore" else snapshot_delete(v, name)
    except NodeError as e:
        return fail(str(e), 500)
    log_activity(current_user.id, f"snapshot_{op}", "vps", v["id"], {"name": name})
    return ok()


@app.route("/vps/<int:vps_id>/reinstall", methods=["POST"])
@vps_route
def vps_reinstall(v):
    if v["user_id"] != current_user.id and not current_user.is_admin:
        return fail("Only the owner can reinstall", 403)
    if not usable(v) or not node_online(v["node_id"]):
        return fail("VPS is suspended or its node is offline", 403)
    image = str(body().get("image", ""))
    allowed = {o["value"] for o in (DOCKER_IMAGES if rt(v) == "docker" else OS_OPTIONS)}
    if image not in allowed and not (current_user.is_admin and IMAGE_RE.match(image)):
        return fail("Choose an operating system from the list.")
    return ok(job=start_job(current_user.id, f"Reinstalling {v['container_name']}", reinstall_vps, v, image, current_user.id))


def _remote_guard(v):
    if not usable(v):
        return fail("This VPS is suspended.", 403)
    if not node_online(v["node_id"]):
        return fail("The node hosting this VPS is offline.", 503)
    if v["status"] != "running":
        return fail("Start the VPS first, then try again.", 409)
    return None


@app.route("/vps/<int:vps_id>/specs")
@vps_route
def vps_specs(v):
    bad = _remote_guard(v)
    if bad:
        return bad
    try:
        return ok(specs=vps_specs_data(v))
    except NodeError as e:
        return fail(str(e), 502)


@app.route("/vps/<int:vps_id>/remote")
@vps_route
def vps_remote(v):
    bad = _remote_guard(v)
    if bad:
        return bad
    try:
        return ok(remote=remote_status(v))
    except NodeError as e:
        return fail(str(e), 502)


@app.route("/vps/<int:vps_id>/remote/<tool>/start", methods=["POST"])
@vps_route
def vps_remote_start(v, tool):
    if tool not in REMOTE_LABEL:
        return fail("Unknown tool", 404)
    bad = _remote_guard(v)
    if bad:
        return bad
    return ok(job=start_job(current_user.id, f"{REMOTE_LABEL[tool]} session for {v['container_name']}", remote_start, v, tool))


@app.route("/vps/<int:vps_id>/remote/stop", methods=["POST"])
@vps_route
def vps_remote_stop(v):
    bad = _remote_guard(v)
    if bad:
        return bad
    try:
        vexec(v, REMOTE_STOP, timeout=30)
    except NodeError as e:
        return fail(str(e), 502)
    log_activity(current_user.id, "remote_sessions_stopped", "vps", v["id"])
    return ok()


@app.route("/vps/<int:vps_id>/share", methods=["POST"])
@vps_route
def vps_share(v):
    if v["user_id"] != current_user.id and not current_user.is_admin:
        return fail("Only the owner can share", 403)
    target = User.by("username", str(body().get("username", "")).strip())
    if not target or target.id == v["user_id"]:
        return fail("No other user with that username.")
    ids = sorted({*[int(i) for i in v["shared_with"]], target.id})
    update_vps(v["id"], shared_with=ids)
    notify(target.id, "info", "VPS shared with you", f"{current_user.username} shared {v['container_name']} with you.")
    log_activity(current_user.id, "share_vps", "vps", v["id"], {"with": target.username})
    return ok()


@app.route("/vps/<int:vps_id>/unshare", methods=["POST"])
@vps_route
def vps_unshare(v):
    if v["user_id"] != current_user.id and not current_user.is_admin:
        return fail("Only the owner can change sharing", 403)
    uid = int(body().get("user_id", 0))
    update_vps(v["id"], shared_with=[i for i in v["shared_with"] if int(i) != uid])
    return ok()


# ============================================================================ remote access (tmate / sshx) + real specs, run INSIDE the VPS
def vexec(v, script, timeout=120):
    """Run a /bin/sh script inside the VPS (works for LXC and Docker). Scripts always exit 0 and report via KEY=value lines."""
    name = v["container_name"]
    argv = ["exec", name, "sh", "-c", script] if rt(v) == "docker" else ["exec", name, "--", "sh", "-c", script]
    return vcli(v, argv, timeout=timeout)


def kv(out):
    d = {}
    for line in (out or "").splitlines():
        if "=" in line:
            k, _, val = line.partition("=")
            if re.match(r"^[A-Z_]{2,24}$", k.strip()):
                d[k.strip()] = val.strip()
    return d


PM_FN = r"""
pm_install() {
  if command -v apt-get >/dev/null 2>&1; then export DEBIAN_FRONTEND=noninteractive; apt-get update -y >/dev/null 2>&1; apt-get install -y "$@" >/dev/null 2>&1
  elif command -v apk >/dev/null 2>&1; then apk add --no-cache "$@" >/dev/null 2>&1
  elif command -v dnf >/dev/null 2>&1; then dnf install -y "$@" >/dev/null 2>&1
  elif command -v yum >/dev/null 2>&1; then yum install -y "$@" >/dev/null 2>&1
  elif command -v pacman >/dev/null 2>&1; then pacman -Sy --noconfirm "$@" >/dev/null 2>&1
  else return 1; fi
}
"""
REMOTE_INSTALL = {
    "tmate": r"""
if ! command -v tmate >/dev/null 2>&1; then
  pm_install tmate || { command -v dnf >/dev/null 2>&1 && pm_install epel-release && pm_install tmate; }
fi
if ! command -v tmate >/dev/null 2>&1; then echo "ERR=tmate could not be installed. The VPS needs internet access and apt, apk, dnf or yum."; exit 0; fi
if ! command -v ssh-keygen >/dev/null 2>&1; then pm_install openssh-client || pm_install openssh-keygen || pm_install openssh-clients; fi
H="${HOME:-/root}"
if command -v ssh-keygen >/dev/null 2>&1 && [ ! -f "$H/.ssh/id_rsa" ]; then mkdir -p "$H/.ssh"; ssh-keygen -q -t rsa -b 2048 -N '' -f "$H/.ssh/id_rsa" >/dev/null 2>&1; fi
echo INSTALLED=1
exit 0
""",
    "sshx": r"""
if ! command -v sshx >/dev/null 2>&1 && [ ! -x /usr/local/bin/sshx ]; then
  command -v curl >/dev/null 2>&1 || pm_install curl ca-certificates tar
  if ! command -v curl >/dev/null 2>&1; then echo "ERR=curl is missing and could not be installed. The VPS needs internet access."; exit 0; fi
  curl -sSf https://sshx.io/get | sh >/dev/null 2>&1
fi
if ! command -v sshx >/dev/null 2>&1 && [ ! -x /usr/local/bin/sshx ]; then echo "ERR=sshx could not be installed. The VPS needs internet access to sshx.io."; exit 0; fi
echo INSTALLED=1
exit 0
""",
}
REMOTE_START = {
    "tmate": r"""
SOCK=/tmp/uiavm-tmate.sock
tmate -S "$SOCK" kill-server >/dev/null 2>&1
rm -f "$SOCK"
tmate -S "$SOCK" new-session -d </dev/null >/dev/null 2>&1
if command -v timeout >/dev/null 2>&1; then timeout 45 tmate -S "$SOCK" wait tmate-ready </dev/null >/dev/null 2>&1; else tmate -S "$SOCK" wait tmate-ready </dev/null >/dev/null 2>&1; fi
SSH=$(tmate -S "$SOCK" display -p '#{tmate_ssh}' 2>/dev/null)
if [ -z "$SSH" ]; then echo "ERR=tmate could not reach its server (ssh.tmate.io). Check that the VPS has outbound internet access."; exit 0; fi
echo "SSH=$SSH"
echo "WEB=$(tmate -S "$SOCK" display -p '#{tmate_web}' 2>/dev/null)"
echo "SSH_RO=$(tmate -S "$SOCK" display -p '#{tmate_ssh_ro}' 2>/dev/null)"
echo "WEB_RO=$(tmate -S "$SOCK" display -p '#{tmate_web_ro}' 2>/dev/null)"
exit 0
""",
    "sshx": r"""
LOG=/tmp/uiavm-sshx.log; PIDF=/tmp/uiavm-sshx.pid
SSHX=$(command -v sshx || true); [ -z "$SSHX" ] && SSHX=/usr/local/bin/sshx
[ -f "$PIDF" ] && kill "$(cat "$PIDF")" 2>/dev/null
rm -f "$LOG" "$PIDF"
if command -v setsid >/dev/null 2>&1; then setsid "$SSHX" -q --name "@@NAME@@" >"$LOG" 2>&1 </dev/null & else nohup "$SSHX" -q --name "@@NAME@@" >"$LOG" 2>&1 </dev/null & fi
echo $! >"$PIDF"
i=0; U=""
while [ $i -lt 25 ]; do U=$(grep -o 'https://[^ ]*' "$LOG" 2>/dev/null | head -1); [ -n "$U" ] && break; i=$((i+1)); sleep 1; done
if [ -n "$U" ]; then echo "URL=$U"; else echo "ERR=sshx started but returned no link. $(head -c 200 "$LOG" 2>/dev/null | tr '\n' ' ')"; fi
exit 0
""",
}
REMOTE_STOP = r"""
tmate -S /tmp/uiavm-tmate.sock kill-server >/dev/null 2>&1; rm -f /tmp/uiavm-tmate.sock
[ -f /tmp/uiavm-sshx.pid ] && kill "$(cat /tmp/uiavm-sshx.pid)" 2>/dev/null; rm -f /tmp/uiavm-sshx.pid
exit 0
"""
REMOTE_STATUS = r"""
SOCK=/tmp/uiavm-tmate.sock; PIDF=/tmp/uiavm-sshx.pid; LOG=/tmp/uiavm-sshx.log
if command -v tmate >/dev/null 2>&1; then echo TMATE_INSTALLED=1; else echo TMATE_INSTALLED=0; fi
if command -v tmate >/dev/null 2>&1 && [ -e "$SOCK" ]; then
  S=$(tmate -S "$SOCK" display -p '#{tmate_ssh}' 2>/dev/null)
  if [ -n "$S" ]; then echo TMATE_ACTIVE=1; echo "TMATE_SSH=$S"; echo "TMATE_WEB=$(tmate -S "$SOCK" display -p '#{tmate_web}' 2>/dev/null)"; fi
fi
if command -v sshx >/dev/null 2>&1 || [ -x /usr/local/bin/sshx ]; then echo SSHX_INSTALLED=1; else echo SSHX_INSTALLED=0; fi
if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF")" 2>/dev/null; then echo SSHX_ACTIVE=1; echo "SSHX_URL=$(grep -o 'https://[^ ]*' "$LOG" 2>/dev/null | head -1)"; fi
exit 0
"""
REMOTE_LABEL = {"tmate": "Tmate", "sshx": "sshx"}


def remote_status(v):
    d = kv(vexec(v, REMOTE_STATUS, timeout=30))
    last = (v.get("metadata") or {}).get("remote", {})
    out = {}
    for tool, P in (("tmate", "TMATE"), ("sshx", "SSHX")):
        active = d.get(P + "_ACTIVE") == "1"
        out[tool] = {"installed": d.get(P + "_INSTALLED") == "1", "active": active, "ended": (not active) and bool(last.get(tool)), "started": last.get(tool)}
    out["tmate"].update(ssh=d.get("TMATE_SSH") or None, web=d.get("TMATE_WEB") or None)
    out["sshx"].update(url=d.get("SSHX_URL") or None)
    return out


def remote_start(job, v, tool):
    label = REMOTE_LABEL[tool]
    job.step(f"Checking that {label} is installed in {v['container_name']} (installs it if missing)")
    r = kv(vexec(v, PM_FN + REMOTE_INSTALL[tool], timeout=300))
    if r.get("ERR"):
        raise NodeError(r["ERR"])
    job.step("Starting a fresh session")
    name = re.sub(r"[^a-z0-9-]", "", v["container_name"].lower())
    r = kv(vexec(v, REMOTE_START[tool].replace("@@NAME@@", f"uiavm-{name}"), timeout=120))
    if r.get("ERR"):
        raise NodeError(r["ERR"])
    meta = dict(get_vps(v["id"])["metadata"])
    meta.setdefault("remote", {})[tool] = now_iso()
    update_vps(v["id"], metadata=meta)
    log_activity(job.d["user_id"], f"{tool}_session", "vps", v["id"])
    job.step("Link ready")
    job.finish(tool=tool)


SPECS_SCRIPT = r"""
. /etc/os-release 2>/dev/null
echo "OS=${PRETTY_NAME:-$(uname -s)}"
echo "KERNEL=$(uname -r)"
echo "ARCH=$(uname -m)"
echo "HOSTNAME=$(hostname 2>/dev/null)"
echo "CPU=$(grep -m1 -i 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2 | sed 's/^ *//')"
echo "PROCS=$(ls /proc 2>/dev/null | grep -c '^[0-9][0-9]*$')"
echo "MEMMAX=$(cat /sys/fs/cgroup/memory.max 2>/dev/null || cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null)"
echo "MEMUSE=$(cat /sys/fs/cgroup/memory.current 2>/dev/null || cat /sys/fs/cgroup/memory/memory.usage_in_bytes 2>/dev/null)"
echo "CPUMAX=$(cat /sys/fs/cgroup/cpu.max 2>/dev/null)"
df -Pk / 2>/dev/null | awk 'NR==2{print "FSTOTAL=" $2*1024; print "FSUSED=" $3*1024}'
exit 0
"""
_specs_cache = {}


def vps_specs_data(v):
    c = _specs_cache.get(v["id"])
    if c and time.time() - c[0] < 8:
        return c[1]
    d = kv(vexec(v, SPECS_SCRIPT, timeout=25))
    num = lambda k: int(d[k]) if d.get(k, "").isdigit() else 0
    live = live_vps(v) or {}
    out = {"os": d.get("OS") or "-", "kernel": d.get("KERNEL") or "-", "arch": d.get("ARCH") or "-", "hostname": d.get("HOSTNAME") or v["container_name"],
           "cpu_model": d.get("CPU") or "-", "procs": num("PROCS") or live.get("procs", 0), "runtime": rt(v),
           "vcpus": int(re.sub(r"\D", "", v["cpu"]) or 1), "mem_limit_mb": round(num("MEMMAX") / 2**20) if 0 < num("MEMMAX") < 2**50 else int(re.sub(r"\D", "", v["ram"]) or 1) * 1024,
           "mem_used_mb": round(num("MEMUSE") / 2**20), "disk_used": num("FSUSED"), "disk_total": num("FSTOTAL"), "image": v["os_version"]}
    if rt(v) == "docker":
        # the container's own filesystem sits on the host disk, so ask Docker for the real size of this container instead of df
        sz = cli(v["node_id"], "docker", ["container", "inspect", "--size", "-f", "{{.SizeRw}}|{{.SizeRootFs}}|{{.Id}}|{{.State.StartedAt}}", v["container_name"]], check=False).split("|")
        if len(sz) >= 4:
            out["disk_used"] = int(sz[1]) if sz[1].isdigit() else out["disk_used"]
            out["container_id"], out["started_at"] = sz[2][:12], sz[3][:19]
            out["disk_changes"] = int(sz[0]) if sz[0].isdigit() else 0
        enforced = (v.get("metadata") or {}).get("disk_enforced", False)
        out["disk_total"] = int(re.sub(r"\D", "", v["storage"]) or 0) * 2**30 if enforced else 0
    elif out["disk_total"] == 0:
        out["disk_total"] = int(re.sub(r"\D", "", v["storage"]) or 0) * 2**30
    _specs_cache[v["id"]] = (time.time(), out)
    return out


# ============================================================================ ports
@app.route("/ports")
@login_required
def ports():
    mine = get_vps_for_user(current_user.id)
    names = [v["container_name"] for v in mine]
    fw = []
    if names:
        fw = q(f"SELECT * FROM port_forwards WHERE vps_container IN ({','.join('?' * len(names))}) ORDER BY created_at DESC", names)
    by_name = {v["container_name"]: v for v in mine}
    for f in fw:
        f["vps_id"], f["host"] = by_name[f["vps_container"]]["id"], vps_host(by_name[f["vps_container"]])
    return render_template("ports.html", forwards=fw, vps=[vps_public(v, False) for v in mine], used=user_ports_used(current_user.id), quota=user_quota(current_user.id))


@app.route("/ports/add", methods=["POST"])
@login_required
def ports_add():
    b = body()
    v = get_vps(int(b.get("vps_id") or 0))
    if not can_access_vps(current_user, v) or not usable(v):
        return fail("VPS not found or suspended", 404)
    try:
        port = int(b.get("vps_port"))
        assert 1 <= port <= 65535
    except Exception:
        return fail("Port must be between 1 and 65535.")
    proto = b.get("protocol", "tcp")
    if proto not in ("tcp", "udp", "tcp,udp"):
        return fail("Protocol must be tcp, udp or both.")
    if rt(v) == "docker" and "udp" in proto:
        return fail("Docker VPS support TCP forwards only. Use an LXC VPS if you need UDP.")
    owner = v["user_id"]
    if user_ports_used(owner) + len(proto.split(",")) * 0 + 1 > user_quota(owner) and not current_user.is_admin:
        return fail(f"Port quota reached ({user_quota(owner)}). Remove a forward or ask an administrator for more.")
    if not node_online(v["node_id"]):
        return fail("The node hosting this VPS is offline.", 503)
    try:
        fid, hp = add_forward(owner, v, port, proto, str(b.get("description", "")))
    except NodeError as e:
        return fail(str(e), 500)
    log_activity(current_user.id, "port_add", "port", hp, {"vps": v["container_name"], "vps_port": port})
    return ok(id=fid, host_port=hp, host=vps_host(v))


@app.route("/ports/<int:fid>/remove", methods=["POST"])
@login_required
def ports_remove(fid):
    f = q("SELECT * FROM port_forwards WHERE id=?", (fid,), one=True)
    v = q("SELECT id FROM vps WHERE container_name=?", (f["vps_container"],), one=True) if f else None
    if not f or not (current_user.is_admin or f["user_id"] == current_user.id or (v and can_access_vps(current_user, get_vps(v["id"])))):
        return fail("Forward not found", 404)
    remove_forward(fid)
    log_activity(current_user.id, "port_remove", "port", f["host_port"])
    return ok()


# ============================================================================ notifications
@app.route("/notifications")
@login_required
def notifications():
    rows = q("SELECT * FROM notifications WHERE user_id=? AND (expires_at IS NULL OR expires_at>?) ORDER BY id DESC LIMIT 100", (current_user.id, now_iso()))
    return render_template("notifications.html", items=rows)


@app.route("/api/notifications")
@login_required
def api_notifications():
    rows = q("SELECT id,type,title,message,read,created_at FROM notifications WHERE user_id=? AND (expires_at IS NULL OR expires_at>?) ORDER BY id DESC LIMIT 12", (current_user.id, now_iso()))
    for r in rows:
        r["ago"] = ago(r["created_at"])
    return jsonify(items=rows, unread=unread_count(current_user.id))


@app.route("/notifications/read", methods=["POST"])
@login_required
def notifications_read():
    nid = body().get("id")
    if nid:
        x("UPDATE notifications SET read=1 WHERE id=? AND user_id=?", (nid, current_user.id))
    else:
        x("UPDATE notifications SET read=1 WHERE user_id=?", (current_user.id,))
    return ok()


@app.route("/notifications/clear", methods=["POST"])
@login_required
def notifications_clear():
    x("DELETE FROM notifications WHERE user_id=?", (current_user.id,))
    return ok()


# ============================================================================ profile + security
@app.route("/profile")
@login_required
def profile():
    sess = session.get("_totp_pending")
    uri = f"otpauth://totp/{get_setting('site_name', PANEL_NAME)}:{current_user.username}?secret={sess}&issuer={get_setting('site_name', PANEL_NAME)}" if sess else None
    return render_template("profile.html", totp_secret=sess, totp_uri=uri,
                           stats={"vps": len(get_vps_for_user(current_user.id)), "ports": user_ports_used(current_user.id), "quota": user_quota(current_user.id)})


@app.route("/profile/update", methods=["POST"])
@login_required
def profile_update():
    b = body()
    kw, vals = [], []
    username = str(b.get("username", "")).strip()
    email = str(b.get("email", "")).strip().lower()
    if username and username != current_user.username:
        err = check_identity(username=username, exclude_id=current_user.id)
        if err:
            return fail(err)
        kw.append("username=?"); vals.append(username)
    if email and email != current_user.email:
        err = check_identity(email=email, exclude_id=current_user.id)
        if err:
            return fail(err)
        kw.append("email=?"); vals.append(email)
    if b.get("theme") in THEMES:
        kw.append("theme=?"); vals.append(b["theme"])
    if kw:
        x(f"UPDATE users SET {', '.join(kw)} WHERE id=?", (*vals, current_user.id))
        if any(k.startswith(("username", "email")) for k in kw):
            log_activity(current_user.id, "profile_update", "user", current_user.id)
    return ok()


@app.route("/profile/password", methods=["POST"])
@login_required
def profile_password():
    b = body()
    if not check_password_hash(current_user.password_hash, b.get("current", "")):
        return fail("Current password is wrong.")
    if len(b.get("new", "")) < 8:
        return fail("New password needs at least 8 characters.")
    x("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(b["new"]), current_user.id))
    log_activity(current_user.id, "password_change", "user", current_user.id)
    return ok()


@app.route("/profile/api-key", methods=["POST"])
@login_required
def profile_api_key():
    key = new_token(48)
    x("UPDATE users SET api_key=? WHERE id=?", (key, current_user.id))
    return ok(api_key=key)


@app.route("/profile/2fa/setup", methods=["POST"])
@login_required
def twofa_setup():
    session["_totp_pending"] = base64.b32encode(secrets.token_bytes(15)).decode().rstrip("=")
    return ok()


@app.route("/profile/2fa/enable", methods=["POST"])
@login_required
def twofa_enable():
    sec = session.get("_totp_pending")
    if not sec or not totp_verify(sec, body().get("code")):
        return fail("That code didn't match. Check your authenticator and try again.")
    x("UPDATE users SET two_factor_secret=?, two_factor_enabled=1 WHERE id=?", (sec, current_user.id))
    session.pop("_totp_pending", None)
    log_activity(current_user.id, "2fa_enabled", "user", current_user.id)
    return ok()


@app.route("/profile/2fa/disable", methods=["POST"])
@login_required
def twofa_disable():
    if not check_password_hash(current_user.password_hash, body().get("password", "")):
        return fail("Password is wrong.")
    x("UPDATE users SET two_factor_secret=NULL, two_factor_enabled=0 WHERE id=?", (current_user.id,))
    log_activity(current_user.id, "2fa_disabled", "user", current_user.id)
    return ok()


# ============================================================================ node enrolment (served BY the panel - no GitHub needed)
INSTALL_SH = r'''#!/usr/bin/env bash
# UIAVM node installer for "@@NAME@@"   -   generated by @@PANEL@@   -   made by reon
set -euo pipefail
PANEL="@@PANEL@@"; TOKEN="@@TOKEN@@"; NAME="@@NAME@@"; PORT="${UIAVM_NODE_PORT:-7071}"
WANT_LXD="@@LXD@@"; WANT_DOCKER="@@DOCKER@@"
ok()  { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
die() { printf '\033[1;31merror:\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "run as root, e.g.  curl -fsSL $PANEL/node/install/... | sudo bash"
ok "Setting up UIAVM node '$NAME'"

if ! command -v python3 >/dev/null 2>&1 || ! command -v curl >/dev/null 2>&1; then
  if   command -v apt-get >/dev/null; then apt-get update -y && apt-get install -y python3 curl
  elif command -v dnf     >/dev/null; then dnf install -y python3 curl
  elif command -v apk     >/dev/null; then apk add python3 curl
  else die "python3 and curl are required"; fi
fi

export PATH="$PATH:/snap/bin"
if [ "$WANT_LXD" = "1" ] && ! command -v lxc >/dev/null 2>&1; then
  ok "LXD not found - installing it"
  if ! command -v snap >/dev/null 2>&1; then
    command -v apt-get >/dev/null && apt-get update -y && apt-get install -y snapd || die "install LXD manually, then re-run this command"
  fi
  snap install lxd && lxd init --auto
fi

if [ "$WANT_DOCKER" = "1" ] && ! command -v docker >/dev/null 2>&1; then
  ok "Docker not found - installing it"
  curl -fsSL https://get.docker.com | sh
  systemctl enable --now docker >/dev/null 2>&1 || true
fi

ok "Installing agent"
install -d -m 755 /opt/uiavm; install -d -m 700 /etc/uiavm
curl -fsSL "$PANEL/node/agent.py?token=$TOKEN" -o /opt/uiavm/uiavm_node.py
chmod 755 /opt/uiavm/uiavm_node.py
cat > /etc/uiavm/node.json <<JSON
{"panel": "$PANEL", "token": "$TOKEN", "port": $PORT, "name": "$NAME"}
JSON
chmod 600 /etc/uiavm/node.json

command -v systemctl >/dev/null 2>&1 || die "systemd not found - run:  python3 /opt/uiavm/uiavm_node.py"
cat > /etc/systemd/system/uiavm-node.service <<UNIT
[Unit]
Description=UIAVM node agent
After=network-online.target snapd.service
Wants=network-online.target
[Service]
Environment=PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin
ExecStart=/usr/bin/env python3 /opt/uiavm/uiavm_node.py
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable uiavm-node >/dev/null 2>&1
systemctl restart uiavm-node

if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then ufw allow "$PORT/tcp" >/dev/null; fi
if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then firewall-cmd --permanent --add-port="$PORT/tcp" >/dev/null && firewall-cmd --reload >/dev/null; fi

sleep 2
systemctl is-active --quiet uiavm-node && ok "Node '$NAME' is running on port $PORT and registering with the panel." || die "agent failed to start - see: journalctl -u uiavm-node"
ok "To remove later:  systemctl disable --now uiavm-node && rm -rf /opt/uiavm /etc/uiavm /etc/systemd/system/uiavm-node.service"
'''


def panel_base():
    return PUBLIC_URL or request.host_url.rstrip("/")


def node_by_token(tok):
    if not tok:
        return None
    for n in q("SELECT * FROM nodes WHERE api_key IS NOT NULL AND is_local=0"):
        if hmac.compare_digest(n["api_key"], tok):
            return _node(n)
    return None


@app.route("/node/install/<token>")
def node_install(token):
    n = node_by_token(token)
    if not n:
        return Response("# invalid or revoked token\nexit 1\n", 403, mimetype="text/plain")
    base = (request.args.get("panel") or panel_base()).rstrip("/")
    sh = (INSTALL_SH.replace("@@PANEL@@", base).replace("@@TOKEN@@", token).replace("@@NAME@@", re.sub(r"[^A-Za-z0-9 _.-]", "", n["name"]))
          .replace("@@DOCKER@@", "1" if request.args.get("docker") == "1" else "0").replace("@@LXD@@", "0" if request.args.get("lxd") == "0" else "1"))
    return Response(sh, mimetype="text/plain")


@app.route("/node/agent.py")
def node_agent_file():
    if not node_by_token(request.args.get("token")):
        abort(403)
    return send_file(BASE_DIR / "uiavm_node.py", mimetype="text/x-python")


@app.route("/api/node/register", methods=["POST"])
def node_register():
    h = request.headers.get("Authorization", "")
    n = node_by_token(h[7:] if h.startswith("Bearer ") else None)
    if not n:
        return jsonify(error="invalid token"), 401
    b = request.get_json(silent=True) or {}
    kw = {"agent_version": str(b.get("agent", ""))[:20], "lxc_version": str(b.get("lxc", ""))[:40], "docker_version": str(b.get("docker", ""))[:40], "last_seen": now_iso()}
    try:
        port = int(b.get("port") or DEFAULT_NODE_PORT)
    except ValueError:
        port = DEFAULT_NODE_PORT
    # URL is auto-managed unless an admin typed one in by hand (which clears agent_port)
    if not n.get("url") or n.get("agent_port"):
        kw["url"] = f"{'https' if b.get('tls') else 'http'}://{request.remote_addr}:{port}"
        kw["agent_port"] = port
    if not n["ip_addresses"]:
        kw["ip_addresses"] = [request.remote_addr]
    if b.get("cpu_cores"):
        kw["cpu_cores"] = int(b["cpu_cores"])
    update_node(n["id"], **kw)
    return jsonify(ok=True, node=n["name"])


# ============================================================================ admin: nodes
@app.route("/admin/nodes")
@admin_required
def admin_nodes():
    return render_template("admin/nodes.html", nodes=[node_card(n) for n in get_nodes()], base=panel_base(), public_set=bool(PUBLIC_URL),
                           node_port=DEFAULT_NODE_PORT)


@app.route("/admin/nodes/create", methods=["POST"])
@admin_required
def admin_node_create():
    b = body()
    entries = b.get("nodes") or [b]
    created, errors = [], []
    for e in entries[:100]:
        name = str(e.get("name", "")).strip()
        if not re.match(r"^[A-Za-z0-9][A-Za-z0-9 _.-]{0,39}$", name):
            errors.append(f"'{name[:30]}': use 1-40 letters, numbers, spaces, dots, dashes")
            continue
        tags = e.get("tags") or []
        tags = [t.strip() for t in tags.split(",")] if isinstance(tags, str) else tags
        tok = new_token(32)
        ip = str(e.get("ip", "")).strip()
        try:
            nid = x("INSERT INTO nodes (name,location,total_vps,tags,api_key,is_local,ip_addresses,ip_aliases,status,created_at,updated_at) VALUES (?,?,?,?,?,0,?,?,?,?,?)",
                    (name, str(e.get("location", ""))[:60], int(e.get("total_vps") or 50), json.dumps([t for t in tags if t]), tok,
                     json.dumps([ip] if ip else []), "[]", "pending", now_iso(), now_iso()))
        except sqlite3.IntegrityError:
            errors.append(f"'{name}' already exists")
            continue
        log_activity(current_user.id, "create_node", "node", nid, {"name": name})
        created.append({"id": nid, "name": name, "ip": ip, "token": tok, "install_path": f"/node/install/{tok}"})
    return jsonify(success=bool(created), created=created, errors=errors) if created else (jsonify(success=False, error="; ".join(errors) or "Nothing to create"), 400)


@app.route("/admin/nodes/<int:nid>/edit", methods=["POST"])
@admin_required
def admin_node_edit(nid):
    n = get_node(nid)
    if not n:
        return fail("Node not found", 404)
    b, kw = body(), {}
    for k in ("name", "location", "notes"):
        if k in b:
            kw[k] = str(b[k]).strip()[:120]
    if "total_vps" in b:
        kw["total_vps"] = max(1, int(b["total_vps"]))
    for k in ("tags", "ip_addresses", "ip_aliases"):
        if k in b:
            kw[k] = [s.strip() for s in (b[k].split(",") if isinstance(b[k], str) else b[k]) if s.strip()]
    if "url" in b and not n["is_local"]:
        kw["url"] = str(b["url"]).strip().rstrip("/") or None
        kw["agent_port"] = None if kw["url"] else n.get("agent_port")   # manual URL = stop auto-updating it
    try:
        update_node(nid, **kw)
    except sqlite3.IntegrityError:
        return fail("Another node already uses that name.")
    log_activity(current_user.id, "edit_node", "node", nid)
    return ok()


@app.route("/admin/nodes/<int:nid>/drain", methods=["POST"])
@admin_required
def admin_node_drain(nid):
    n = get_node(nid)
    if not n:
        return fail("Node not found", 404)
    update_node(nid, drain=0 if n["drain"] else 1)
    return ok(drain=not n["drain"])


@app.route("/admin/nodes/<int:nid>/regenerate-key", methods=["POST"])
@admin_required
def admin_node_regen(nid):
    n = get_node(nid)
    if not n or n["is_local"]:
        return fail("Only remote nodes have tokens", 400)
    tok = new_token(32)
    update_node(nid, api_key=tok, url=None, agent_port=None, status="pending")
    log_activity(current_user.id, "regenerate_node_token", "node", nid)
    return ok(token=tok, install_path=f"/node/install/{tok}")


@app.route("/admin/nodes/<int:nid>/command")
@admin_required
def admin_node_command(nid):
    n = get_node(nid)
    if not n or n["is_local"]:
        return fail("Not a remote node", 400)
    return ok(token=n["api_key"], install_path=f"/node/install/{n['api_key']}", name=n["name"])


@app.route("/admin/nodes/<int:nid>/check")
@admin_required
def admin_node_check(nid):
    n = get_node(nid)
    if not n:
        return fail("Node not found", 404)
    st = poll_node(n)
    info = {"card": node_card(n), "storage": None, "networks": None, "images": None}
    if st["online"]:
        for key, argv in (("storage", ["storage", "list", "--format", "json"]), ("networks", ["network", "list", "--format", "json"])):
            try:
                data = json.loads(lxc(n, argv, timeout=15, check=False) or "[]")
                info[key] = [{"name": d.get("name"), "driver": d.get("driver"), "managed": d.get("managed", True), "used_by": len(d.get("used_by") or [])}
                             for d in data if d.get("managed", True)]
            except Exception:
                pass
    if st["online"] and (st.get("runtimes") or {}).get("docker"):
        try:
            info["docker"] = dkr(n, ["info", "--format", "{{.Driver}} storage, {{.Containers}} containers, {{.Images}} images"], timeout=15, check=False)
        except Exception:
            pass
    return ok(**info)


@app.route("/admin/nodes/<int:nid>/delete", methods=["POST"])
@admin_required
def admin_node_delete(nid):
    n = get_node(nid)
    if not n or n["is_local"]:
        return fail("The local node can't be removed.", 400)
    count = node_vps_count(nid)
    if count and not body().get("force"):
        return fail(f"This node still hosts {count} VPS. Remove them first, or force-remove the node (containers are deleted).")
    if count:
        for v in get_all_vps():
            if v["node_id"] == nid:
                try: delete_vps_full(v, current_user.id)
                except Exception: x("DELETE FROM vps WHERE id=?", (v["id"],))
    x("DELETE FROM nodes WHERE id=?", (nid,))
    NODE_STATE.pop(nid, None)
    log_activity(current_user.id, "delete_node", "node", nid, {"name": n["name"]})
    return ok()


# ============================================================================ admin: users
@app.route("/admin/users")
@admin_required
def admin_users():
    rows = q("""SELECT u.id,u.username,u.email,u.is_admin,u.is_main_admin,u.created_at,u.last_login,u.two_factor_enabled,u.api_key,
                (SELECT COUNT(*) FROM vps WHERE user_id=u.id) vps_count,
                COALESCE((SELECT allocated_ports FROM port_allocations WHERE user_id=u.id),0) quota
                FROM users u ORDER BY u.id""")
    return render_template("admin/users.html", users=rows)


@app.route("/admin/users/create", methods=["POST"])
@admin_required
def admin_user_create():
    b = body()
    name, email, pw = str(b.get("username", "")).strip(), str(b.get("email", "")).strip().lower(), str(b.get("password", ""))
    err = check_identity(name, email) or ("Password needs at least 8 characters." if len(pw) < 8 else None)
    if err:
        return fail(err)
    is_admin = 1 if b.get("is_admin") in (True, "true", "on", 1) else 0     # any admin can create admins
    uid = x("INSERT INTO users (username,email,password_hash,is_admin,created_at,api_key) VALUES (?,?,?,?,?,?)",
            (name, email, generate_password_hash(pw), is_admin, now_iso(), new_token(48)))
    x("INSERT INTO port_allocations (user_id,allocated_ports,updated_at) VALUES (?,?,?)", (uid, int(b.get("quota") or get_setting("default_port_quota", 5)), now_iso()))
    log_activity(current_user.id, "create_admin" if is_admin else "create_user", "user", uid, {"username": name})
    return ok(id=uid)


@app.route("/admin/users/<int:uid>/edit", methods=["POST"])
@admin_required
def admin_user_edit(uid):
    u = User.by("id", uid)
    if not u:
        return fail("User not found", 404)
    b = body()
    if u.is_main_admin and not current_user.is_main_admin:
        return fail("Only the main admin can edit the main admin.", 403)
    if b.get("username") and str(b["username"]).strip() != u.username:
        err = check_identity(username=str(b["username"]).strip(), exclude_id=uid)
        if err:
            return fail(err)
        x("UPDATE users SET username=? WHERE id=?", (str(b["username"]).strip(), uid))
    if b.get("email") and str(b["email"]).strip().lower() != u.email:
        err = check_identity(email=str(b["email"]).strip().lower(), exclude_id=uid)
        if err:
            return fail(err)
        x("UPDATE users SET email=? WHERE id=?", (str(b["email"]).strip().lower(), uid))
    if "quota" in b:
        x("INSERT INTO port_allocations (user_id,allocated_ports,updated_at) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET allocated_ports=excluded.allocated_ports, updated_at=excluded.updated_at",
          (uid, max(0, int(b["quota"])), now_iso()))
    if "is_admin" in b and not u.is_main_admin:
        want = 1 if b["is_admin"] in (True, "true", "on", 1) else 0
        if uid == current_user.id and not want:
            return fail("You can't remove your own admin rights.")
        x("UPDATE users SET is_admin=? WHERE id=?", (want, uid))
    if b.get("password"):
        if len(b["password"]) < 8:
            return fail("Password needs at least 8 characters.")
        x("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(b["password"]), uid))
    if b.get("disable_2fa"):
        x("UPDATE users SET two_factor_enabled=0, two_factor_secret=NULL WHERE id=?", (uid,))
    log_activity(current_user.id, "edit_user", "user", uid)
    return ok()


@app.route("/admin/users/<int:uid>/impersonate", methods=["POST"])
@admin_required
def admin_impersonate(uid):
    """Sign in as another account. A banner lets the admin return; everything is logged."""
    u = User.by("id", uid)
    if session.get("impersonator"):
        return fail("Return to your own account first.")
    if not u or u.id == current_user.id:
        return fail("Pick a different account.")
    if u.is_main_admin and not current_user.is_main_admin:
        return fail("Only the main admin can sign in as the main admin.", 403)
    log_activity(current_user.id, "impersonate", "user", uid, {"as": u.username})
    session["impersonator"] = current_user.id
    login_user(u)
    return ok(url=url_for("dashboard"))


@app.route("/impersonate/stop", methods=["POST"])
@login_required
def impersonate_stop():
    aid = session.pop("impersonator", None)
    admin = User.by("id", aid) if aid else None
    if not admin or not admin.is_admin:
        return fail("Not impersonating.")
    login_user(admin)
    return ok(url=url_for("admin_users"))


@app.route("/admin/users/<int:uid>/api-key", methods=["POST"])
@admin_required
def admin_user_api_key(uid):
    key = new_token(48)
    x("UPDATE users SET api_key=? WHERE id=?", (key, uid))
    return ok(api_key=key)


@app.route("/admin/users/<int:uid>/delete", methods=["POST"])
@admin_required
def admin_user_delete(uid):
    u = User.by("id", uid)
    if not u or u.is_main_admin or u.id == current_user.id:
        return fail("That account can't be deleted.", 400)
    owned = [v for v in get_all_vps() if v["user_id"] == uid]
    if owned and not body().get("delete_vps"):
        return fail(f"{u.username} owns {len(owned)} VPS. Delete them too, or reassign them first.")
    for v in owned:
        try: delete_vps_full(v, current_user.id)
        except Exception as e: logger.error(f"delete {v['container_name']}: {e}")
    x("DELETE FROM users WHERE id=?", (uid,))
    log_activity(current_user.id, "delete_user", "user", uid, {"username": u.username})
    return ok()


# ============================================================================ admin: VPS
@app.route("/admin/vps")
@admin_required
def admin_vps():
    return redirect(url_for("vps_list", all=1))


@app.route("/admin/vps/create", methods=["GET", "POST"])
@admin_required
def admin_vps_create():
    if request.method == "GET":
        return render_template("admin/vps_create.html", users=q("SELECT id,username FROM users ORDER BY username"),
                               nodes=[node_card(n) for n in get_nodes()], profiles=CONTAINER_PROFILES,
                               default_profile=get_setting("default_profile", "docker"), docker_images=DOCKER_IMAGES,
                               tags=sorted({t for n in get_nodes() for t in n["tags"]}))
    b = body()
    runtime = b.get("runtime") if b.get("runtime") in ("lxc", "docker") else "lxc"
    try:
        uid, ram, cpu, disk = int(b["user_id"]), int(b.get("ram", 2)), int(b.get("cpu", 2)), int(b.get("disk", 20))
        assert 1 <= ram <= 512 and 1 <= cpu <= 128 and 1 <= disk <= 4000
    except Exception:
        return fail("Check the resources: RAM 1-512 GB, CPU 1-128 cores, disk 1-4000 GB, and choose an owner.")
    owner = User.by("id", uid)
    if not owner:
        return fail("Owner not found.")
    if not owner.is_admin and len(get_vps_for_user(uid)) >= int(get_setting("max_vps_per_user", 10)):
        return fail(f"{owner.username} has reached the VPS limit ({get_setting('max_vps_per_user', 10)}).")
    node = pick_node(b.get("tag") or None, runtime) if str(b.get("node_id")) in ("auto", "", "None") else get_node(int(b["node_id"]))
    if not node:
        return fail(f"No online node with free capacity can run {RUNTIME_LABEL[runtime]} right now. Add a node, or install {RUNTIME_LABEL[runtime]} on one.")
    if not node_online(node["id"]):
        return fail(f"{node['name']} is offline.")
    if not node_has(node["id"], runtime):
        return fail(f"{node['name']} doesn't have {RUNTIME_LABEL[runtime]} installed. Pick another node or install it there.")
    if node_vps_count(node["id"]) >= node["total_vps"]:
        return fail(f"{node['name']} is at capacity ({node['total_vps']} VPS).")
    name = re.sub(r"[^a-z0-9-]", "", str(b.get("name") or "").lower().replace("_", "-").replace(" ", "-")).strip("-")
    if not name:
        name = re.sub(r"[^a-z0-9-]", "", f"uia-{owner.username.lower()[:10]}-{secrets.token_hex(2)}")
    if not NAME_RE.match(name):
        return fail("Name must start with a letter and use only lowercase letters, numbers and dashes (max 42).")
    if q("SELECT 1 FROM vps WHERE container_name=?", (name,), one=True):
        return fail(f"A VPS named {name} already exists.")
    image = str(b.get("custom_image") or b.get("image") or "ubuntu:24.04").strip()
    if not IMAGE_RE.match(image):
        return fail("Image names may only contain letters, numbers and : _ . / + -")
    profile = b.get("profile") if b.get("profile") in CONTAINER_PROFILES else get_setting("default_profile", "docker")
    ip = None if runtime == "docker" else (str(b.get("ip_address") or "").strip() or None)
    keep = b.get("keepalive")
    keep = docker_keepalive(image) if keep in (None, "") else keep in (True, "true", "on", 1, "1")
    p = dict(user_id=uid, node_id=node["id"], name=name, image=image, ram=ram, cpu=cpu, disk=disk, profile=profile, runtime=runtime,
             keepalive=keep, ip_address=ip, ip_alias=(str(b.get("ip_alias") or "").strip() or None))
    return ok(job=start_job(current_user.id, f"Creating {name} ({RUNTIME_LABEL[runtime]})", provision_vps, current_user.id, p), name=name, node=node["name"], runtime=runtime)


@app.route("/admin/vps/<int:vps_id>/edit", methods=["POST"])
@admin_required
def admin_vps_edit(vps_id):
    v = get_vps(vps_id)
    if not v:
        return fail("VPS not found", 404)
    b, kw = body(), {}
    try:
        ram, cpu, disk = int(b.get("ram", 0)), int(b.get("cpu", 0)), int(b.get("disk", 0))
    except ValueError:
        return fail("RAM, CPU and disk must be numbers.")
    node, name, docker, notice = get_node(v["node_id"]), v["container_name"], rt(v) == "docker", None
    try:
        if ram and f"{ram}GB" != v["ram"]:
            if docker: dkr(node, ["update", "--memory", f"{ram * 1024}m", "--memory-swap", f"{ram * 1024}m", name])
            else: lxc(node, ["config", "set", name, "limits.memory", f"{ram * 1024}MiB"])
            kw["ram"] = f"{ram}GB"
        if cpu and str(cpu) != v["cpu"]:
            if docker: dkr(node, ["update", "--cpus", str(cpu), name])
            else: lxc(node, ["config", "set", name, "limits.cpu", str(cpu)])
            kw["cpu"] = str(cpu)
        if disk and f"{disk}GB" != v["storage"]:
            if docker:
                notice = "Docker can't resize a container's disk, so the disk size was left unchanged."
            else:
                try: lxc(node, ["config", "device", "set", name, "root", f"size={disk}GiB"])
                except NodeError: lxc(node, ["config", "device", "override", name, "root", f"size={disk}GiB"])
                kw["storage"] = f"{disk}GB"
    except NodeError as e:
        return fail(f"The node refused the change: {e}", 500)
    if "ip_alias" in b:
        kw["ip_alias"] = str(b["ip_alias"]).strip() or None
    if b.get("user_id") and int(b["user_id"]) != v["user_id"] and User.by("id", int(b["user_id"])):
        kw["user_id"] = int(b["user_id"])
        x("UPDATE port_forwards SET user_id=? WHERE vps_container=?", (kw["user_id"], name))
    if kw:
        r, c, s_ = kw.get("ram", v["ram"]), kw.get("cpu", v["cpu"]), kw.get("storage", v["storage"])
        kw["config"] = f"{r} RAM / {c} CPU / {s_} Disk"
        update_vps(vps_id, **kw)
    log_activity(current_user.id, "edit_vps", "vps", vps_id, kw)
    return ok(notice=notice)


@app.route("/admin/vps/<int:vps_id>/suspend", methods=["POST"])
@admin_required
def admin_vps_suspend(vps_id):
    v = get_vps(vps_id)
    if not v:
        return fail("VPS not found", 404)
    reason = str(body().get("reason") or "Suspended by administrator")[:200]
    suspend_vps(v, reason, current_user.username)
    notify(v["user_id"], "warn", "VPS suspended", f"{v['container_name']}: {reason}")
    return ok()


@app.route("/admin/vps/<int:vps_id>/unsuspend", methods=["POST"])
@admin_required
def admin_vps_unsuspend(vps_id):
    v = get_vps(vps_id)
    if not v:
        return fail("VPS not found", 404)
    hist = v["suspension_history"] + [{"time": now_iso(), "reason": "Unsuspended", "by": current_user.username}]
    update_vps(vps_id, suspended=0, suspended_reason=None, suspension_history=hist)
    try:
        power(get_vps(vps_id), "start", current_user.id)
    except NodeError as e:
        logger.warning(f"unsuspend start failed: {e}")
    notify(v["user_id"], "success", "VPS restored", f"{v['container_name']} is active again.")
    log_activity(current_user.id, "unsuspend_vps", "vps", vps_id)
    return ok()


@app.route("/admin/vps/<int:vps_id>/whitelist", methods=["POST"])
@admin_required
def admin_vps_whitelist(vps_id):
    v = get_vps(vps_id)
    if not v:
        return fail("VPS not found", 404)
    update_vps(vps_id, whitelisted=0 if v["whitelisted"] else 1)
    return ok(whitelisted=not v["whitelisted"])


@app.route("/admin/vps/<int:vps_id>/delete", methods=["POST"])
@admin_required
def admin_vps_delete(vps_id):
    v = get_vps(vps_id)
    if not v:
        return fail("VPS not found", 404)
    try:
        delete_vps_full(v, current_user.id)
    except NodeError as e:
        return fail(str(e), 500)
    return ok()


# ============================================================================ admin: settings, logs, system
SETTING_KEYS = ["site_name", "site_description", "footer_text", "maintenance_message", "default_port_quota", "max_vps_per_user", "max_snapshots",
                "cpu_threshold", "ram_threshold", "suspend_grace_minutes", "backup_retention", "default_profile"]
SETTING_FLAGS = ["maintenance_mode", "registration_enabled", "auto_suspend", "backup_enabled", "bootstrap_packages"]


@app.route("/admin/settings", methods=["GET", "POST"])
@admin_required
def admin_settings():
    if request.method == "POST":
        b = body()
        for k in SETTING_KEYS:
            if k in b:
                set_setting(k, str(b[k]).strip()[:300])
        for k in SETTING_FLAGS:
            if k in b:
                set_setting(k, "1" if b[k] in (True, "true", "on", "1", 1) else "0")
        log_activity(current_user.id, "update_settings", "settings")
        return ok()
    backups = sorted(os.listdir(BASE_DIR / "backups"), reverse=True)[:12] if (BASE_DIR / "backups").exists() else []
    import platform
    sysinfo = {"Panel": f"{PANEL_NAME} {PANEL_VERSION}", "Python": platform.python_version(), "Platform": platform.platform(),
               "Database": f"{os.path.getsize(DB_PATH) / 1024:.0f} KB", "Real-time console": "on" if SOCKETIO else "off (install flask-socketio)",
               "Users": q("SELECT COUNT(*) n FROM users", one=True)["n"], "VPS": q("SELECT COUNT(*) n FROM vps", one=True)["n"],
               "Nodes": q("SELECT COUNT(*) n FROM nodes", one=True)["n"], "Poll interval": f"{POLL_INTERVAL}s"}
    return render_template("admin/settings.html", s={r["key"]: r["value"] for r in q("SELECT key,value FROM settings")}, profiles=CONTAINER_PROFILES,
                           backups=backups, sysinfo=sysinfo)


@app.route("/admin/backup", methods=["POST"])
@admin_required
def admin_backup():
    name = backup_database()
    log_activity(current_user.id, "backup_db", "system", name)
    return ok(name=name)


@app.route("/admin/backup/<name>")
@admin_required
def admin_backup_download(name):
    p = BASE_DIR / "backups" / os.path.basename(name)
    if not p.exists() or p.suffix != ".db":
        abort(404)
    return send_file(p, as_attachment=True)


@app.route("/admin/emergency/<action>", methods=["POST"])
@admin_required
def admin_emergency(action):
    if body().get("confirm") != "CONFIRM":
        return fail("Type CONFIRM to continue.")
    n = 0
    if action == "clear-suspensions":
        for v in get_all_vps():
            if v["suspended"]:
                update_vps(v["id"], suspended=0, suspended_reason=None); n += 1
    elif action in ("stop-all", "restart-all"):
        for v in get_all_vps():
            if v["status"] in ("running", "frozen") and node_online(v["node_id"]):
                try:
                    power(v, "stop" if action == "stop-all" else "restart", current_user.id); n += 1
                except NodeError as e:
                    logger.error(f"{action} {v['container_name']}: {e}")
    else:
        return fail("Unknown action")
    log_activity(current_user.id, f"emergency_{action}", "system", None, {"affected": n})
    return ok(affected=n)


@app.route("/admin/logs")
@admin_required
def admin_logs():
    page, term = max(1, int(request.args.get("page", 1))), request.args.get("q", "").strip()
    where, params = "", []
    if term:
        where, params = "WHERE a.action LIKE ? OR u.username LIKE ? OR a.details LIKE ? OR a.resource_id LIKE ?", [f"%{term}%"] * 4
    total = q(f"SELECT COUNT(*) n FROM activity_logs a LEFT JOIN users u ON u.id=a.user_id {where}", params, one=True)["n"]
    rows = q(f"SELECT a.*, u.username FROM activity_logs a LEFT JOIN users u ON u.id=a.user_id {where} ORDER BY a.id DESC LIMIT 50 OFFSET ?", [*params, (page - 1) * 50])
    return render_template("admin/logs.html", rows=rows, page=page, pages=max(1, (total + 49) // 50), term=term, total=total)


# ============================================================================ REST API v1  (X-API-Key header)
@app.route("/api/v1/me")
@api_key_required
def v1_me():
    u = request.api_user
    return jsonify(id=u.id, username=u.username, email=u.email, is_admin=u.is_admin)


@app.route("/api/v1/vps")
@api_key_required
def v1_vps():
    u = request.api_user
    return jsonify([vps_public(v) for v in (get_all_vps() if u.is_admin else get_vps_for_user(u.id))])


@app.route("/api/v1/vps/<int:vps_id>")
@api_key_required
def v1_vps_one(vps_id):
    v = get_vps(vps_id)
    return jsonify(vps_public(v)) if can_access_vps(request.api_user, v) else (jsonify(error="not found"), 404)


@app.route("/api/v1/vps/<int:vps_id>/power", methods=["POST"])
@api_key_required
def v1_power(vps_id):
    v = get_vps(vps_id)
    u = request.api_user
    if not can_access_vps(u, v):
        return jsonify(error="not found"), 404
    if v["suspended"] and not u.is_admin:
        return jsonify(error="suspended"), 403
    action = (request.get_json(silent=True) or {}).get("action")
    try:
        power(v, action, u.id)
        return jsonify(ok=True, status=get_vps(vps_id)["status"])
    except NodeError as e:
        return jsonify(error=str(e)), 500


@app.route("/api/v1/nodes")
@api_key_required
def v1_nodes():
    if not request.api_user.is_admin:
        return jsonify(error="admin only"), 403
    return jsonify([node_card(n) for n in get_nodes()])


@app.route("/health")
def health():
    return jsonify(status="ok", version=PANEL_VERSION, nodes_online=sum(1 for s in NODE_STATE.values() if s.get("online")))


# ============================================================================ errors
@app.errorhandler(404)
def e404(e):
    if request.path.startswith("/api/"):
        return jsonify(error="not found"), 404
    return render_template("errors/404.html"), 404


@app.errorhandler(500)
def e500(e):
    logger.error(f"500 on {request.path}: {e}")
    if request.path.startswith("/api/") or request.is_json:
        return jsonify(success=False, error="Internal error - check uiavm.log"), 500
    return render_template("errors/500.html"), 500


# ============================================================================ web console (Socket.IO + PTY, local and remote nodes)
CONSOLES: Dict[Any, dict] = {}

if socketio:
    @socketio.on("connect")
    def ws_connect():
        if not current_user.is_authenticated:
            return False
        join_room(f"user_{current_user.id}")
        if current_user.is_admin:
            join_room("admins")

    @socketio.on("join_vps")
    def ws_join_vps(d):
        v = get_vps(int(d.get("vps_id", 0)))
        if can_access_vps(current_user, v):
            join_room(f"vps_{v['id']}")

    def _console_pump(key, node, pid, sid):
        st = CONSOLES.get(key)
        try:
            while st and not st["stop"].is_set():
                if node["is_local"]:
                    s = agent.pty_manager.get(pid)
                    if not s:
                        break
                    data, closed = s.read(5)
                else:
                    r = node_call(node, "GET", f"/v1/pty/{pid}/read?timeout=15", timeout=25)
                    data, closed = base64.b64decode(r["data"]), r["closed"]
                if data:
                    socketio.emit("console_out", {"vps_id": key[1], "data": base64.b64encode(data).decode()}, to=sid)
                if closed:
                    socketio.emit("console_closed", {"vps_id": key[1]}, to=sid)
                    break
        except Exception as e:
            socketio.emit("console_closed", {"vps_id": key[1], "error": str(e)}, to=sid)
        finally:
            _console_close(key)

    def _console_close(key):
        st = CONSOLES.pop(key, None)
        if not st:
            return
        st["stop"].set()
        try:
            if st["node"]["is_local"]:
                agent.pty_manager.close(st["pid"])
            else:
                node_call(st["node"], "POST", f"/v1/pty/{st['pid']}/close", {}, timeout=5)
        except Exception:
            pass

    @socketio.on("console_open")
    def ws_console_open(d):
        if not current_user.is_authenticated:
            return
        v = get_vps(int(d.get("vps_id", 0)))
        if not can_access_vps(current_user, v) or not usable(v):
            return emit("console_closed", {"vps_id": d.get("vps_id"), "error": "Not allowed"})
        key = (request.sid, v["id"])
        _console_close(key)
        node = get_node(v["node_id"])
        try:
            if (live_vps(v) or {}).get("status", v["status"]) != "running":
                raise NodeError("Start the VPS to open a console.")
            cols, rows = int(d.get("cols", 120)), int(d.get("rows", 32))
            if node["is_local"]:
                pid = agent.pty_manager.open(v["container_name"], cols, rows, rt(v))
            else:
                pid = node_call(node, "POST", "/v1/pty/open", {"container": v["container_name"], "cols": cols, "rows": rows, "runtime": rt(v)})["id"]
        except Exception as e:
            return emit("console_closed", {"vps_id": v["id"], "error": str(e)})
        CONSOLES[key] = {"node": node, "pid": pid, "stop": threading.Event()}
        threading.Thread(target=_console_pump, args=(key, node, pid, request.sid), daemon=True).start()
        log_activity(current_user.id, "console_open", "vps", v["id"])
        emit("console_ready", {"vps_id": v["id"]})

    def _console_send(d, fn_local, fn_remote):
        st = CONSOLES.get((request.sid, int(d.get("vps_id", 0))))
        if not st:
            return
        try:
            (fn_local if st["node"]["is_local"] else fn_remote)(st)
        except Exception:
            pass

    @socketio.on("console_in")
    def ws_console_in(d):
        raw = str(d.get("data", "")).encode()
        _console_send(d, lambda st: (agent.pty_manager.get(st["pid"]) or (_ for _ in ()).throw(KeyError)).write(raw),
                      lambda st: node_call(st["node"], "POST", f"/v1/pty/{st['pid']}/write", {"data": base64.b64encode(raw).decode()}, timeout=5))

    @socketio.on("console_resize")
    def ws_console_resize(d):
        c, r = int(d.get("cols", 120)), int(d.get("rows", 32))
        _console_send(d, lambda st: agent.pty_manager.get(st["pid"]).resize(c, r),
                      lambda st: node_call(st["node"], "POST", f"/v1/pty/{st['pid']}/resize", {"cols": c, "rows": r}, timeout=5))

    @socketio.on("console_close")
    def ws_console_close(d):
        _console_close((request.sid, int(d.get("vps_id", 0))))

    @socketio.on("disconnect")
    def ws_disconnect():
        for key in [k for k in CONSOLES if k[0] == request.sid]:
            _console_close(key)


# ============================================================================ CLI
def outward_ip():
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("203.0.113.1", 9))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def install_cmd(base, tok, docker=False, lxd=True):
    qs = (["docker=1"] if docker else []) + ([] if lxd else ["lxd=0"])
    url = f"{base}/node/install/{tok}" + ("?" + "&".join(qs) if qs else "")
    return f'curl -fsSL "{url}" | sudo bash' if qs else f"curl -fsSL {url} | sudo bash"


def cli_node(args):
    init_db()
    base = (args.panel or PUBLIC_URL or f"http://{outward_ip()}:{PORT}").rstrip("/")
    if args.cmd == "list":
        for n in get_nodes():
            kind = "local" if n["is_local"] else (n["url"] or "waiting for agent")
            print(f"  [{n['id']}] {n['name']:<20} {n['location'] or '-':<12} {kind}")
        return
    if args.cmd == "remove":
        n = next((n for n in get_nodes() if n["name"] == args.name), None)
        if not n or n["is_local"]:
            sys.exit("no such remote node")
        if node_vps_count(n["id"]):
            sys.exit("node still hosts VPS - remove them from the panel first")
        x("DELETE FROM nodes WHERE id=?", (n["id"],))
        print(f"removed {n['name']}")
        return
    if args.cmd == "token":
        n = next((n for n in get_nodes() if n["name"] == args.name and not n["is_local"]), None)
        if not n:
            sys.exit("no such remote node")
        print(install_cmd(base, n["api_key"], args.docker, not args.no_lxd))
        return
    # add: --name may repeat, or --file with "name,location,ip" lines
    specs = [(n, args.location, None) for n in (args.name or [])]
    if args.file:
        for line in Path(args.file).read_text().splitlines():
            parts = [p.strip() for p in line.split(",")]
            if parts and parts[0] and not parts[0].startswith("#"):
                specs.append((parts[0], parts[1] if len(parts) > 1 else args.location, parts[2] if len(parts) > 2 else None))
    if not specs:
        sys.exit("give --name NAME (repeatable) or --file nodes.txt")
    made = []
    for name, loc, ip in specs:
        tok = new_token(32)
        try:
            x("INSERT INTO nodes (name,location,total_vps,tags,api_key,is_local,ip_addresses,ip_aliases,status,created_at,updated_at) VALUES (?,?,?,?,?,0,?,?,?,?,?)",
              (name, loc or "", args.slots, "[]", tok, json.dumps([ip] if ip else []), "[]", "pending", now_iso(), now_iso()))
        except sqlite3.IntegrityError:
            print(f"  skipped {name}: already exists", file=sys.stderr)
            continue
        made.append((name, ip, install_cmd(base, tok, args.docker, not args.no_lxd)))
    print()
    for name, ip, cmd in made:
        print(f"# {name}\n{cmd}\n")
    ssh = [m for m in made if m[1]]
    if ssh:
        print(f"# --- or push to every server over SSH in one go ({args.ssh_user}@) ---")
        for name, ip, cmd in ssh:
            print(f"ssh -o StrictHostKeyChecking=accept-new {args.ssh_user}@{ip} '{cmd}' &")
        print("wait")


def cli_admin(args):
    init_db()
    from getpass import getpass
    u = User.by("username", args.user) if args.user else next(iter(q("SELECT username FROM users WHERE is_main_admin=1")), None)
    u = u if isinstance(u, User) else (User.by("username", u["username"]) if u else None)
    if not u:
        sys.exit("user not found")
    pw = args.password or getpass(f"new password for {u.username}: ")
    if len(pw) < 8:
        sys.exit("password needs at least 8 characters")
    x("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(pw), u.id))
    print(f"password updated for {u.username}")


def run_panel():
    init_db()
    (BASE_DIR / "backups").mkdir(exist_ok=True)
    agent.forwards_load()        # restore Docker port forwards for this machine's own node
    threading.Thread(target=monitor_loop, daemon=True, name="uiavm-monitor").start()
    logger.info(f"{PANEL_NAME} v{PANEL_VERSION} (made by {PANEL_AUTHOR}) listening on http://{HOST}:{PORT}  realtime={SOCKETIO}")
    if socketio:
        socketio.run(app, host=HOST, port=PORT, debug=DEBUG, allow_unsafe_werkzeug=True, use_reloader=False)
    else:
        app.run(host=HOST, port=PORT, debug=DEBUG, threaded=True, use_reloader=False)


def main():
    ap = argparse.ArgumentParser(prog="uiavm", description="UIAVM panel - made by reon")
    sub = ap.add_subparsers(dest="mode")
    n = sub.add_parser("node", help="manage nodes from the shell")
    n.add_argument("cmd", choices=["add", "list", "remove", "token"])
    n.add_argument("name", nargs="?", help="node name (for remove/token)")
    n.add_argument("--name", dest="name", action="append", help="node name; repeat for several nodes")
    n.add_argument("--file", help="text file, one 'name,location,ip' per line")
    n.add_argument("--location", default="")
    n.add_argument("--slots", type=int, default=50, help="max VPS on each new node")
    n.add_argument("--panel", help="panel URL the nodes will call back (default: auto-detected)")
    n.add_argument("--ssh-user", default="root")
    n.add_argument("--docker", action="store_true", help="also install Docker on the node")
    n.add_argument("--no-lxd", action="store_true", help="don't install LXD (Docker-only node)")
    a = sub.add_parser("admin", help="admin utilities")
    a.add_argument("cmd", choices=["reset-password"])
    a.add_argument("--user")
    a.add_argument("--password")
    args = ap.parse_args()
    if args.mode == "node":
        if args.cmd in ("remove", "token"):
            args.name = args.name[0] if isinstance(args.name, list) else args.name
        cli_node(args)
    elif args.mode == "admin":
        cli_admin(args)
    else:
        run_panel()


if __name__ == "__main__":
    main()
