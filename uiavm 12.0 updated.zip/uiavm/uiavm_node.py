#!/usr/bin/env python3
"""
uiavm_node.py - UIAVM node agent                                  made by reon

Runs on every LXC host you want to manage from the UIAVM panel.
Standard library only - no pip install needed.

  * Authenticated with a per-node token (Bearer, constant-time compare)
  * Only ever executes `lxc ...` or `docker ...` as an argv list - never a shell, never anything else
  * One /v1/snapshot call returns host + every container's live stats
  * Streams interactive terminals (PTY) so the web console works on remote nodes
  * Registers itself with the panel and keeps heartbeating, so you never type a node URL

The panel also imports this file for its own "local" node, so local and remote
nodes behave identically.
"""
import argparse
import base64
import hmac
import json
import os
import pty
import shutil
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

AGENT_VERSION = "2.0.0"
CONFIG_PATH = os.environ.get("UIAVM_NODE_CONFIG", "/etc/uiavm/node.json")
STATE_DIR = os.environ.get("UIAVM_NODE_STATE", os.path.dirname(CONFIG_PATH) or ".")   # where port-forward state is kept


# --------------------------------------------------------------------------- host stats
class HostSampler(threading.Thread):
    """Samples /proc/stat in the background so CPU% is a real delta, never a guess."""

    def __init__(self):
        super().__init__(daemon=True)
        self.cpu = 0.0
        self._last = self._read()
        self.start()

    @staticmethod
    def _read():
        try:
            with open("/proc/stat") as f:
                v = [float(x) for x in f.readline().split()[1:]]
            return v[3] + (v[4] if len(v) > 4 else 0), sum(v)
        except Exception:
            return 0.0, 0.0

    def run(self):
        while True:
            time.sleep(2)
            idle, total = self._read()
            li, lt = self._last
            if total > lt:
                self.cpu = round(max(0.0, min(100.0, 100.0 * (1 - (idle - li) / (total - lt)))), 1)
            self._last = (idle, total)


_sampler = None


def host_stats():
    global _sampler
    if _sampler is None:
        _sampler = HostSampler()
    mem = {}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":", 1)
                mem[k] = int(v.split()[0]) // 1024  # MB
    except Exception:
        pass
    total = mem.get("MemTotal", 0)
    avail = mem.get("MemAvailable", mem.get("MemFree", 0))
    used = max(0, total - avail)
    try:
        du = shutil.disk_usage("/")
        disk = {"total_gb": round(du.total / 2**30, 1), "used_gb": round(du.used / 2**30, 1),
                "percent": round(du.used / du.total * 100, 1) if du.total else 0.0}
    except Exception:
        disk = {"total_gb": 0, "used_gb": 0, "percent": 0.0}
    try:
        with open("/proc/uptime") as f:
            up = int(float(f.read().split()[0]))
    except Exception:
        up = 0
    try:
        load = [round(x, 2) for x in os.getloadavg()]
    except Exception:
        load = [0, 0, 0]
    return {
        "cpu": _sampler.cpu, "cpu_cores": os.cpu_count() or 1, "load": load,
        "ram": {"total": total, "used": used, "percent": round(used / total * 100, 1) if total else 0.0},
        "disk": disk, "uptime_s": up, "hostname": socket.gethostname(),
        "kernel": os.uname().release, "time": time.time(),
    }


# --------------------------------------------------------------------------- lxc
def cli_run(tool, argv, timeout=120, stdin=None):
    """Run `<tool> <argv...>` where tool is lxc or docker. argv is a list; nothing is ever passed through a shell."""
    if tool not in ("lxc", "docker"):
        raise ValueError("unsupported tool")
    if not isinstance(argv, list) or not argv or not all(isinstance(a, str) for a in argv):
        raise ValueError("argv must be a non-empty list of strings")
    if argv[0] == tool:
        argv = argv[1:]
    try:
        p = subprocess.run([tool] + argv, capture_output=True, text=True, timeout=timeout, input=stdin)
        return {"returncode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
    except subprocess.TimeoutExpired:
        return {"returncode": 124, "stdout": "", "stderr": f"timed out after {timeout}s"}
    except FileNotFoundError:
        return {"returncode": 127, "stdout": "", "stderr": f"{tool} is not installed on this node"}


def lxc_run(argv, timeout=120, stdin=None):
    return cli_run("lxc", argv, timeout, stdin)


def docker_run(argv, timeout=120, stdin=None):
    return cli_run("docker", argv, timeout, stdin)


_snap_cache = {"t": 0.0, "data": None}
_snap_lock = threading.Lock()


def containers_snapshot(max_age=2.0):
    """One `lxc list --format json` -> compact per-container state (cached briefly)."""
    with _snap_lock:
        if _snap_cache["data"] is not None and time.time() - _snap_cache["t"] < max_age:
            return _snap_cache["data"]
        res = lxc_run(["list", "--format", "json"], timeout=30)
        out = {}
        if res["returncode"] != 0:
            out = {"__error__": {"name": "__error__", "status": (res["stderr"] or "lxc list failed").strip()[:300], "missing": res["returncode"] == 127}}
        else:
            try:
                for c in json.loads(res["stdout"] or "[]"):
                    st = c.get("state") or {}
                    net = st.get("network") or {}
                    ips, rx, tx = [], 0, 0
                    for ifname, info in net.items():
                        if ifname == "lo":
                            continue
                        for a in info.get("addresses", []):
                            if a.get("scope") == "global":
                                ips.append(a.get("address"))
                        cnt = info.get("counters") or {}
                        rx += cnt.get("bytes_received", 0)
                        tx += cnt.get("bytes_sent", 0)
                    cfg = c.get("expanded_config") or c.get("config") or {}
                    dev = c.get("expanded_devices") or {}
                    out[c["name"]] = {
                        "name": c["name"], "status": (c.get("status") or "Unknown").lower(),
                        "cpu_ns": (st.get("cpu") or {}).get("usage", 0),
                        "mem_used": (st.get("memory") or {}).get("usage", 0),
                        "mem_limit": cfg.get("limits.memory", ""), "cpu_limit": cfg.get("limits.cpu", ""),
                        "disk_used": ((st.get("disk") or {}).get("root") or {}).get("usage", 0),
                        "disk_limit": (dev.get("root") or {}).get("size", ""),
                        "procs": st.get("processes", 0), "ips": ips, "rx": rx, "tx": tx,
                        "image": (c.get("config") or {}).get("image.description", ""),
                        "snapshots": len(c.get("snapshots") or []),
                    }
            except Exception as e:  # malformed output should never kill the agent
                out = {"__error__": {"name": "__error__", "status": str(e)}}
        _snap_cache.update(t=time.time(), data=out)
        return out


def lxc_version():
    r = lxc_run(["--version"], timeout=10)
    return r["stdout"].strip() if r["returncode"] == 0 else "not installed"


_UNITS = {"b": 1, "kb": 1e3, "mb": 1e6, "gb": 1e9, "tb": 1e12, "kib": 2**10, "mib": 2**20, "gib": 2**30, "tib": 2**40}


def _bytes(txt):
    """'10.5MiB' / '1.2kB' -> bytes"""
    import re
    m = re.match(r"^\s*([\d.]+)\s*([a-zA-Z]*)", str(txt or ""))
    return int(float(m.group(1)) * _UNITS.get((m.group(2) or "b").lower(), 1)) if m else 0


_rt_cache = {"t": 0.0, "v": None}


def runtimes():
    """Which container runtimes this node can use, with versions (cached for a minute)."""
    if _rt_cache["v"] is not None and time.time() - _rt_cache["t"] < 60:
        return _rt_cache["v"]
    lx = lxc_run(["--version"], timeout=10)
    dk = docker_run(["version", "--format", "{{.Server.Version}}"], timeout=10)
    v = {"lxc": lx["stdout"].strip() if lx["returncode"] == 0 and lx["stdout"].strip() else None,
         "docker": dk["stdout"].strip() if dk["returncode"] == 0 and dk["stdout"].strip() else None}
    _rt_cache.update(t=time.time(), v=v)
    return v


_dk_cache = {"t": 0.0, "data": None}
_dk_lock = threading.Lock()
_DK_STATE = {"running": "running", "restarting": "running", "paused": "frozen"}


def docker_containers(max_age=3.0):
    """Every UIAVM-managed Docker container with live stats, in the same shape the panel uses for LXC."""
    with _dk_lock:
        if _dk_cache["data"] is not None and time.time() - _dk_cache["t"] < max_age:
            return _dk_cache["data"]
        r = docker_run(["ps", "-a", "--filter", "label=uiavm=1", "--format", "{{json .}}"], timeout=20)
        out = {}
        if r["returncode"] != 0:
            out = {"__error__": {"name": "__error__", "status": (r["stderr"] or "docker ps failed").strip()[:300], "missing": r["returncode"] == 127}}
        else:
            try:
                rows = [json.loads(l) for l in r["stdout"].splitlines() if l.strip()]
                names = [x["Names"] for x in rows]
                info = {}
                if names:
                    i = docker_run(["inspect", "--format", "{{.Name}}|{{range .NetworkSettings.Networks}}{{.IPAddress}} {{end}}|{{.HostConfig.NanoCpus}}|{{.HostConfig.Memory}}"] + names, timeout=20)
                    for line in i["stdout"].splitlines():
                        p = line.split("|")
                        if len(p) >= 4:
                            info[p[0].lstrip("/")] = {"ips": p[1].split(), "nano": int(p[2] or 0), "mem": int(p[3] or 0)}
                stats = {}
                running = [x["Names"] for x in rows if x.get("State") == "running"]
                if running:
                    st = docker_run(["stats", "--no-stream", "--format", "{{json .}}"] + running, timeout=30)
                    for line in st["stdout"].splitlines():
                        if line.strip():
                            d = json.loads(line)
                            stats[d.get("Name")] = d
                for x in rows:
                    n = x["Names"]
                    d, inf = stats.get(n, {}), info.get(n, {})
                    mu = (d.get("MemUsage") or "0 / 0").split("/")
                    nio = (d.get("NetIO") or "0 / 0").split("/")
                    out[n] = {"name": n, "status": _DK_STATE.get(x.get("State", ""), "stopped"), "runtime": "docker",
                              "cpu_pct": float(str(d.get("CPUPerc", "0")).strip("%") or 0), "mem_used": _bytes(mu[0]),
                              "mem_limit": inf.get("mem", 0) or _bytes(mu[1]) if len(mu) > 1 else inf.get("mem", 0),
                              "cpu_cores": inf.get("nano", 0) / 1e9, "procs": int(d.get("PIDs") or 0), "ips": inf.get("ips", []),
                              "rx": _bytes(nio[0]), "tx": _bytes(nio[1]) if len(nio) > 1 else 0, "image": x.get("Image", "")}
            except Exception as e:
                out = {"__error__": {"name": "__error__", "status": f"docker parse error: {e}", "missing": False}}
        _dk_cache.update(t=time.time(), data=out)
        return out


def snapshot():
    return {"host": host_stats(), "containers": containers_snapshot(), "docker": docker_containers() if shutil.which("docker") else
            {"__error__": {"name": "__error__", "status": "docker is not installed", "missing": True}},
            "runtimes": runtimes(), "agent": AGENT_VERSION}


# --------------------------------------------------------------------------- terminals
class PtySession:
    def __init__(self, container, cols=120, rows=32, runtime="lxc"):
        self.id = uuid.uuid4().hex[:16]
        self.master, slave = pty.openpty()
        self._resize_fd(self.master, cols, rows)
        script = "command -v bash >/dev/null 2>&1 && exec bash -l || exec sh -l"
        argv = (["docker", "exec", "-it", "-e", "TERM=xterm-256color", container, "sh", "-c", script] if runtime == "docker"
                else ["lxc", "exec", container, "--env", "TERM=xterm-256color", "--", "sh", "-c", script])
        self.proc = subprocess.Popen(
            argv,
            stdin=slave, stdout=slave, stderr=slave, preexec_fn=os.setsid, close_fds=True)
        os.close(slave)
        self.buf = bytearray()
        self.cv = threading.Condition()
        self.closed = False
        self.touched = time.time()
        threading.Thread(target=self._pump, daemon=True).start()

    @staticmethod
    def _resize_fd(fd, cols, rows):
        import fcntl, termios
        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", int(rows), int(cols), 0, 0))

    def _pump(self):
        while True:
            try:
                data = os.read(self.master, 8192)
            except OSError:
                data = b""
            with self.cv:
                if not data:
                    self.closed = True
                    self.cv.notify_all()
                    return
                self.buf += data
                self.cv.notify_all()

    def write(self, data: bytes):
        self.touched = time.time()
        os.write(self.master, data)

    def read(self, timeout=15.0):
        self.touched = time.time()
        with self.cv:
            if not self.buf and not self.closed:
                self.cv.wait(timeout)
            data, self.buf = bytes(self.buf), bytearray()
            return data, self.closed

    def resize(self, cols, rows):
        try:
            self._resize_fd(self.master, cols, rows)
        except Exception:
            pass

    def close(self):
        try:
            os.killpg(os.getpgid(self.proc.pid), signal.SIGTERM)
        except Exception:
            pass
        try:
            os.close(self.master)
        except Exception:
            pass
        self.closed = True


class PtyManager:
    def __init__(self):
        self.sessions = {}
        self.lock = threading.Lock()
        threading.Thread(target=self._reap, daemon=True).start()

    def open(self, container, cols=120, rows=32, runtime="lxc"):
        s = PtySession(container, cols, rows, runtime)
        with self.lock:
            self.sessions[s.id] = s
        return s.id

    def get(self, sid):
        with self.lock:
            return self.sessions.get(sid)

    def close(self, sid):
        with self.lock:
            s = self.sessions.pop(sid, None)
        if s:
            s.close()

    def _reap(self):
        while True:
            time.sleep(30)
            now = time.time()
            with self.lock:
                dead = [k for k, s in self.sessions.items() if now - s.touched > 600 or (s.closed and not s.buf)]
            for k in dead:
                self.close(k)


pty_manager = PtyManager()


# --------------------------------------------------------------------------- port forwards for Docker VPS
class Forwarder:
    """Host port -> container port TCP proxy. LXC uses native proxy devices; Docker can't add ports after creation."""

    def __init__(self, host_port, container, port):
        self.host_port, self.container, self.port = int(host_port), container, int(port)
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("0.0.0.0", self.host_port))
        self.sock.listen(64)
        self.ip, self.ip_t, self.alive = "", 0.0, True
        threading.Thread(target=self._accept, daemon=True).start()

    def _target(self):
        if self.ip and time.time() - self.ip_t < 15:
            return self.ip
        r = docker_run(["inspect", "-f", "{{range .NetworkSettings.Networks}}{{.IPAddress}} {{end}}", self.container], timeout=10)
        ips = r["stdout"].split() if r["returncode"] == 0 else []
        self.ip, self.ip_t = (ips[0] if ips else ""), time.time()
        return self.ip

    def _accept(self):
        while self.alive:
            try:
                c, _ = self.sock.accept()
            except OSError:
                return
            if not self.alive:          # woken by close(): release the port for real
                c.close()
                return
            threading.Thread(target=self._serve, args=(c,), daemon=True).start()

    def _serve(self, c):
        try:
            ip = self._target()
            if not ip:
                c.close()
                return
            u = socket.create_connection((ip, self.port), timeout=8)
            u.settimeout(None)
        except OSError:
            self.ip = ""
            c.close()
            return

        def pump(a, b):
            try:
                while True:
                    d = a.recv(65536)
                    if not d:
                        break
                    b.sendall(d)
            except OSError:
                pass
            finally:
                for sk in (a, b):
                    try:
                        sk.shutdown(socket.SHUT_RDWR)
                    except OSError:
                        pass
        threading.Thread(target=pump, args=(c, u), daemon=True).start()
        pump(u, c)
        c.close()
        u.close()

    def close(self):
        self.alive = False
        try:                              # wake the blocked accept() so the listening socket is actually freed
            socket.create_connection(("127.0.0.1", self.host_port), timeout=1).close()
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass


FORWARDS = {}
_fw_lock = threading.Lock()


def _fw_save():
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(os.path.join(STATE_DIR, "uiavm-forwards.json"), "w") as f:
            json.dump([{"host_port": h, "container": x.container, "port": x.port} for h, x in FORWARDS.items()], f)
    except OSError:
        pass


def forward_op(op, host_port, container=None, port=None):
    with _fw_lock:
        try:
            hp = int(host_port)
            if op == "add":
                cur = FORWARDS.get(hp)
                if cur and cur.container == container and cur.port == int(port):
                    return {"ok": True}
                if cur:
                    cur.close()
                FORWARDS[hp] = Forwarder(hp, str(container), int(port))
            elif op == "remove":
                f = FORWARDS.pop(hp, None)
                if f:
                    f.close()
            else:
                return {"ok": False, "error": "unknown operation"}
            _fw_save()
            return {"ok": True}
        except OSError as e:
            return {"ok": False, "error": f"cannot listen on port {host_port}: {e.strerror or e}"}
        except (TypeError, ValueError):
            return {"ok": False, "error": "bad arguments"}


def forwards_load():
    """Re-create saved forwards after the agent/panel restarts."""
    try:
        with open(os.path.join(STATE_DIR, "uiavm-forwards.json")) as f:
            saved = json.load(f)
    except (OSError, ValueError):
        return
    for e in saved:
        forward_op("add", e.get("host_port"), e.get("container"), e.get("port"))


# --------------------------------------------------------------------------- http agent
class Agent(BaseHTTPRequestHandler):
    server_version = "uiavm-node/" + AGENT_VERSION
    token = ""
    node_name = ""

    def log_message(self, fmt, *args):  # quiet; systemd journal stays readable
        if os.environ.get("UIAVM_NODE_VERBOSE"):
            sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _auth(self):
        sent = self.headers.get("Authorization", "")
        sent = sent[7:] if sent.startswith("Bearer ") else ""
        if not sent or not hmac.compare_digest(sent.encode(), self.token.encode()):
            self._json({"error": "unauthorized"}, 401)
            return False
        return True

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 4 * 1024 * 1024:
            return {}
        try:
            return json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return {}

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/v1/health":
            return self._json({"ok": True, "name": self.node_name, "agent": AGENT_VERSION})
        if not self._auth():
            return
        if u.path == "/v1/snapshot":
            return self._json(snapshot())
        if u.path == "/v1/info":
            return self._json({"agent": AGENT_VERSION, "lxc": lxc_version(), "runtimes": runtimes(), "host": host_stats()})
        if u.path == "/v1/forwards":
            return self._json([{"host_port": h, "container": f.container, "port": f.port} for h, f in FORWARDS.items()])
        if u.path.startswith("/v1/pty/") and u.path.endswith("/read"):
            s = pty_manager.get(u.path.split("/")[3])
            if not s:
                return self._json({"error": "no such session", "closed": True}, 404)
            t = float(parse_qs(u.query).get("timeout", ["15"])[0])
            data, closed = s.read(min(t, 25))
            return self._json({"data": base64.b64encode(data).decode(), "closed": closed})
        self._json({"error": "not found"}, 404)

    def do_POST(self):
        if not self._auth():
            return
        u, b = urlparse(self.path), self._body()
        try:
            if u.path == "/v1/exec":
                return self._json(cli_run(b.get("runtime") or "lxc", b.get("argv") or [], int(b.get("timeout", 120)), b.get("stdin")))
            if u.path == "/v1/forward":
                return self._json(forward_op(b.get("op"), b.get("host_port"), b.get("container"), b.get("port")))
            if u.path == "/v1/pty/open":
                return self._json({"id": pty_manager.open(str(b["container"]), b.get("cols", 120), b.get("rows", 32), b.get("runtime") or "lxc")})
            parts = u.path.split("/")  # ['', 'v1', 'pty', id, action]
            if len(parts) == 5 and parts[2] == "pty":
                s = pty_manager.get(parts[3])
                if not s:
                    return self._json({"error": "no such session"}, 404)
                if parts[4] == "write":
                    s.write(base64.b64decode(b.get("data", "")))
                elif parts[4] == "resize":
                    s.resize(b.get("cols", 120), b.get("rows", 32))
                elif parts[4] == "close":
                    pty_manager.close(parts[3])
                return self._json({"ok": True})
        except Exception as e:
            return self._json({"error": str(e)}, 500)
        self._json({"error": "not found"}, 404)


def register_loop(panel, token, port, name, tls=False):
    """Tell the panel who we are (and that we're alive). Retries forever."""
    url = panel.rstrip("/") + "/api/node/register"
    while True:
        try:
            payload = json.dumps({"port": port, "hostname": socket.gethostname(), "agent": AGENT_VERSION,
                                  "lxc": lxc_version(), "docker": runtimes().get("docker") or "", "cpu_cores": os.cpu_count() or 1,
                                  "name": name, "tls": tls}).encode()
            req = urllib.request.Request(url, payload, {"Content-Type": "application/json",
                                                        "Authorization": "Bearer " + token})
            urllib.request.urlopen(req, timeout=10).read()
            delay = 30
        except Exception as e:
            sys.stderr.write(f"[uiavm-node] panel unreachable ({e}); retrying\n")
            delay = 10
        time.sleep(delay)


def load_config(args):
    cfg = {}
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
    for k in ("panel", "token", "port", "name", "bind", "cert", "key"):
        v = getattr(args, k, None)
        if v not in (None, ""):
            cfg[k] = v
    return cfg


def main():
    ap = argparse.ArgumentParser(description="UIAVM node agent")
    ap.add_argument("--panel", help="panel URL, e.g. http://203.0.113.10:5000")
    ap.add_argument("--token", help="node token from the panel")
    ap.add_argument("--port", type=int, help="listen port (default 7071)")
    ap.add_argument("--bind", help="listen address (default 0.0.0.0)")
    ap.add_argument("--name", help="node name (informational)")
    ap.add_argument("--cert", help="TLS certificate (optional)")
    ap.add_argument("--key", help="TLS key (optional)")
    ap.add_argument("--version", action="store_true")
    args = ap.parse_args()
    if args.version:
        print(AGENT_VERSION)
        return
    cfg = load_config(args)
    if not cfg.get("token"):
        sys.exit("No token. Add this node in the panel first, then run the install command it shows.")
    port = int(cfg.get("port", 7071))
    Agent.token, Agent.node_name = cfg["token"], cfg.get("name", "")
    host_stats()  # start the CPU sampler
    forwards_load()
    srv = ThreadingHTTPServer((cfg.get("bind", "0.0.0.0"), port), Agent)
    srv.daemon_threads = True
    if cfg.get("cert") and cfg.get("key"):
        import ssl
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cfg["cert"], cfg["key"])
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    if cfg.get("panel"):
        threading.Thread(target=register_loop, args=(cfg["panel"], cfg["token"], port, cfg.get("name", ""), bool(cfg.get("cert"))),
                         daemon=True).start()
    print(f"[uiavm-node] v{AGENT_VERSION} listening on {cfg.get('bind', '0.0.0.0')}:{port}", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
