/* UIAVM gate v12: aurora + topology network + rotating globe + typing preview + tilt card */
(function () {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches, root = document.documentElement;
  const css = n => getComputedStyle(root).getPropertyValue(n).trim() || '#4fd8ff';
  const rgb = h => { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/(.)/g, '$1$1'); return [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)).join(','); };
  const DPR = () => Math.min(2, devicePixelRatio || 1);

  fxNetwork(document.getElementById('net'));
  fxGlobe(document.getElementById('globe'));

  /* ---- typing activity preview */
  const out = document.getElementById('termOut');
  if (out && getComputedStyle(out).display !== 'none') {
    const L = [['sig', 'node sg-01 joined the cluster'], ['m', 'lxc    ubuntu:24.04 -> running in 9.1s'], ['m', 'docker nginx:stable -> running in 3.8s'], ['ok', 'forward :8080 -> web1:80 active'], ['sig', 'snapshot before-upgrade saved'], ['ok', 'cluster healthy, 3 of 3 nodes online']];
    const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    if (reduce) out.innerHTML = L.map(l => `<span class="${l[0]}">${esc(l[1])}</span>`).join('\n');
    else (async function loop() {
      for (;;) {
        let html = '';
        for (const [cls, text] of L) {
          for (let i = 1; i <= text.length; i++) { out.innerHTML = html + `<span class="${cls}">${esc(text.slice(0, i))}</span><i class="caret"></i>`; await new Promise(r => setTimeout(r, 22 + Math.random() * 30)); if (document.hidden) await new Promise(r => setTimeout(r, 500)); }
          html += `<span class="${cls}">${esc(text)}</span>\n`; out.innerHTML = html + '<i class="caret"></i>'; await new Promise(r => setTimeout(r, 380));
        }
        await new Promise(r => setTimeout(r, 2600));
      }
    })();
  }

  /* ---- tilt + glare on the card */
  const tilt = document.getElementById('tilt'), gate = document.getElementById('gate');
  if (tilt && !reduce && matchMedia('(pointer:fine)').matches) {
    let raf; gate.addEventListener('pointermove', e => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => {
      const r = tilt.getBoundingClientRect(), px = (e.clientX - r.left) / r.width - .5, py = (e.clientY - r.top) / r.height - .5, cl = v => Math.max(-.9, Math.min(.9, v));
      tilt.style.setProperty('--ry', (cl(px) * 7).toFixed(2) + 'deg'); tilt.style.setProperty('--rx', (-cl(py) * 6).toFixed(2) + 'deg');
      tilt.style.setProperty('--gx', ((px + .5) * 100).toFixed(1) + '%'); tilt.style.setProperty('--gy', ((py + .5) * 100).toFixed(1) + '%'); }); });
    gate.addEventListener('pointerleave', () => { tilt.style.setProperty('--rx', '0deg'); tilt.style.setProperty('--ry', '0deg'); });
  }
})();

document.addEventListener('DOMContentLoaded', () => {
  const forms = {login: document.getElementById('f-login'), register: document.getElementById('f-register')};
  function gate(which) {
    if (!forms[which]) return;
    Object.entries(forms).forEach(([k, f]) => f && (f.hidden = k !== which));
    document.querySelectorAll('.seg [data-gate]').forEach(b => b.classList.toggle('on', b.dataset.gate === which));
    history.replaceState(null, '', which === 'register' ? '/register' : '/login');
    const first = forms[which].querySelector('input:not([type=hidden])'); if (first) setTimeout(() => first.focus(), 30);
  }
  document.querySelectorAll('[data-gate]').forEach(b => b.addEventListener('click', () => gate(b.dataset.gate)));
  document.querySelectorAll('[data-eye]').forEach(b => b.addEventListener('click', () => {
    const i = document.getElementById(b.dataset.eye), show = i.type === 'password'; i.type = show ? 'text' : 'password'; b.classList.toggle('on', show); b.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  }));
  document.querySelectorAll('input[type=password]').forEach(i => ['keydown', 'keyup'].forEach(ev => i.addEventListener(ev, e => { const c = document.getElementById('caps'); if (c && e.getModifierState) c.hidden = !e.getModifierState('CapsLock'); })));
  const rp = document.getElementById('rp'), rc = document.getElementById('rc');
  if (rp) {
    const labels = ['At least 8 characters.', 'Weak - add length or variety.', 'Fair', 'Good', 'Strong'];
    const score = v => { if (!v) return 0; let s = 0; if (v.length >= 8) s++; if (v.length >= 12) s++; if (/[a-z]/.test(v) && /[A-Z]/.test(v)) s++; if (/\d/.test(v) && /[^A-Za-z0-9]/.test(v)) s++; return v.length < 8 ? Math.min(s, 1) : Math.max(1, s); };
    const upd = () => { const s = score(rp.value); document.getElementById('strength').dataset.s = s; document.getElementById('strengthTxt').textContent = labels[s];
      document.getElementById('matchTxt').hidden = !rc.value || rc.value === rp.value; };
    rp.addEventListener('input', upd); rc.addEventListener('input', upd);
    forms.register.addEventListener('submit', e => { if (rp.value !== rc.value) { e.preventDefault(); document.getElementById('matchTxt').hidden = false; rc.focus(); } else forms.register.querySelector('.submit').classList.add('busy'); });
  }
  forms.login.addEventListener('submit', () => forms.login.querySelector('.submit').classList.add('busy'));
});
