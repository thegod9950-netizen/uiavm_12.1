/* UIAVM frontend runtime                                              made by reon */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const CSRF = ($('meta[name=csrf]') || {}).content || '';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const ico = (n, c = '') => `<svg class="i ${c}"><use href="#i-${n}"/></svg>`;

/* ---------- network */
async function api(url, data, method = 'POST') {
  const opt = {method, headers: {'X-CSRF-Token': CSRF, 'Accept': 'application/json'}};
  if (data !== undefined && method !== 'GET') { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(data); }
  let res, j;
  try { res = await fetch(url, opt); } catch (e) { throw new Error('Cannot reach the panel. Check your connection.'); }
  try { j = await res.json(); } catch (e) { throw new Error(`Unexpected response (HTTP ${res.status}).`); }
  if (!res.ok || j.success === false) throw new Error(j.error || `Request failed (HTTP ${res.status}).`);
  return j;
}
const get = url => api(url, undefined, 'GET');

/* ---------- feedback */
function toast(title, msg = '', type = 'info', ms = 4800) {
  let box = $('.toasts');
  if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('role', 'status'); document.body.append(box); }
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.innerHTML = `<b>${esc(title)}</b>${msg ? `<span>${esc(msg)}</span>` : ''}`;
  box.append(t);
  setTimeout(() => { t.style.opacity = 0; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 300); }, ms);
}
const fail = e => toast('Something went wrong', e.message || String(e), 'error', 7000);

async function busy(btn, fn) {
  if (btn) btn.classList.add('busy');
  try { return await fn(); } catch (e) { fail(e); } finally { if (btn) btn.classList.remove('busy'); }
}

/* ---------- dialogs */
function dlg(id) { return document.getElementById(id); }
function openDlg(id) { const d = dlg(id); d.showModal(); const f = $('input:not([type=hidden]),select,textarea', d); if (f) setTimeout(() => f.focus(), 30); return d; }
function closeDlg(id) { dlg(id).close(); }
document.addEventListener('click', e => {
  const c = e.target.closest('[data-close]');
  if (c) { c.closest('dialog').close(); return; }
  const o = e.target.closest('[data-open]');
  if (o) { openDlg(o.dataset.open); return; }
  if (e.target.matches('dialog.modal')) e.target.close();
  const cp = e.target.closest('[data-copy]');
  if (cp) copyText(cp.dataset.copy.startsWith('#') ? $(cp.dataset.copy).textContent : cp.dataset.copy);
});

function confirmBox({title, text = '', confirm = 'Confirm', danger = false, typed = ''}) {
  return new Promise(res => {
    const d = document.createElement('dialog');
    d.className = 'modal';
    d.innerHTML = `<div class="panel"><div class="panel-h"><h2>${esc(title)}</h2></div><p class="muted">${text}</p>
      ${typed ? `<div class="field" style="margin-top:14px"><label>Type <b class="mono">${esc(typed)}</b> to continue</label><input class="input" autocomplete="off"></div>` : ''}
      <div class="foot-act"><button class="btn" data-v="0">Cancel</button><button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-v="1" ${typed ? 'disabled' : ''}>${esc(confirm)}</button></div></div>`;
    document.body.append(d);
    const ok = $('[data-v="1"]', d);
    if (typed) $('input', d).addEventListener('input', e => ok.disabled = e.target.value !== typed);
    d.addEventListener('click', e => { const v = e.target.closest('[data-v]'); if (v) { d.close(); res(v.dataset.v === '1'); } else if (e.target === d) { d.close(); res(false); } });
    d.addEventListener('cancel', () => res(false));
    d.addEventListener('close', () => setTimeout(() => d.remove(), 50));
    d.showModal();
  });
}

function copyText(t) {
  const done = () => toast('Copied', '', 'success', 1600);
  if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(t).then(done, () => fallbackCopy(t, done));
  else fallbackCopy(t, done);
}
function fallbackCopy(t, done) {
  const a = document.createElement('textarea'); a.value = t; a.style.position = 'fixed'; a.style.opacity = 0; document.body.append(a); a.select();
  try { document.execCommand('copy'); done(); } catch (e) { toast('Copy failed', 'Select the text and copy it manually.', 'warn'); } a.remove();
}

/* ---------- formatting */
const fmtBytes = n => { n = +n || 0; const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; while (n >= 1024 && i < 4) { n /= 1024; i++; } return (i ? n.toFixed(1) : n.toFixed(0)) + ' ' + u[i]; };
const fmtRate = n => fmtBytes(n) + '/s';
const pctClass = p => p >= 90 ? 'bad' : p >= 75 ? 'warn' : '';
const fmtUp = s => { if (!s) return '-'; const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : `${m}m`; };
function setBar(el, p) { if (!el) return; p = Math.max(0, Math.min(100, p || 0)); el.className = 'bar ' + pctClass(p); el.firstElementChild.style.width = p + '%'; }

/* ---------- charts (no libraries) */
function sizeCanvas(c) {
  const r = c.getBoundingClientRect(), d = window.devicePixelRatio || 1;
  if (c.width !== Math.round(r.width * d)) { c.width = Math.round(r.width * d); c.height = Math.round(r.height * d); }
  const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0); x.clearRect(0, 0, r.width, r.height);
  return [x, r.width, r.height];
}
const cssVar = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
function lineChart(c, series, {max = 100, grid = true, fill = true} = {}) {
  if (!c) return; const [x, w, h] = sizeCanvas(c); const pad = 3;
  if (grid) { x.strokeStyle = cssVar('--line'); x.lineWidth = 1; x.beginPath(); for (let i = 1; i < 4; i++) { const y = Math.round(h * i / 4) + .5; x.moveTo(0, y); x.lineTo(w, y); } x.stroke(); }
  series.forEach(s => {
    const d = s.data; if (!d || d.length < 2) return;
    const m = typeof max === 'function' ? max(d) : max, col = s.color.startsWith('--') ? cssVar(s.color) : s.color;
    const pts = d.map((v, i) => [i / (d.length - 1) * w, h - pad - Math.min(v, m) / (m || 1) * (h - pad * 2)]);
    x.beginPath(); pts.forEach((p, i) => i ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1]));
    x.strokeStyle = col; x.lineWidth = 1.8; x.lineJoin = 'round'; x.stroke();
    if (fill) { x.lineTo(w, h); x.lineTo(0, h); x.closePath(); const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, col + '44'); g.addColorStop(1, col + '00'); x.fillStyle = g; x.fill(); }
  });
}
const spark = (c, data, color = '--sig') => lineChart(c, [{data, color}], {max: d => Math.max(10, ...d), grid: false});

/* concentric ring gauge: [{value, cls}] outer->inner */
function buildRings(el, labels) {
  const R = [114, 92, 70];
  el.innerHTML = `<svg viewBox="0 0 260 260" aria-hidden="true">${R.map((r, i) => {
    const c = 2 * Math.PI * r; return `<circle class="track" cx="130" cy="130" r="${r}"/><circle class="val r${i + 1}" cx="130" cy="130" r="${r}" style="--c:${c}"/>`; }).join('')}</svg>
    <div class="sweep"></div><div class="mid"><b>0%</b><span>${esc(labels || 'CPU load')}</span></div>`;
}
function setRings(el, vals, mid) {
  $$('.val', el).forEach((c, i) => { const C = parseFloat(c.style.getPropertyValue('--c')); c.style.strokeDashoffset = C * (1 - Math.min(100, vals[i] || 0) / 100); });
  if (mid !== undefined) $('.mid b', el).textContent = mid;
}

/* ---------- live polling */
function live(cb, ms = 3000) {
  let t, stop = false;
  const tick = async () => {
    if (stop) return;
    if (!document.hidden) { try { cb(await get('/api/live')); } catch (e) { /* keep last values on screen */ } }
    t = setTimeout(tick, ms);
  };
  tick();
  return () => { stop = true; clearTimeout(t); };
}

/* ---------- long jobs (create / reinstall) */
function trackJob(id, title) {
  return new Promise((resolve, reject) => {
    const d = dlg('jobDlg'); $('#jobTitle').textContent = title; $('#jobSteps').innerHTML = ''; $('#jobErr').hidden = true; $('#jobClose').hidden = true;
    if (!d.open) d.showModal();
    const timer = setInterval(async () => {
      try {
        const j = await get('/api/jobs/' + id);
        $('#jobSteps').innerHTML = j.steps.map((s, i) => `<li class="${i === j.steps.length - 1 && j.status === 'running' ? 'live' : ''}">${i === j.steps.length - 1 && j.status === 'running' ? '<span class="btn busy btn-ghost btn-icon btn-sm" style="padding:0;width:18px;height:18px"></span>' : ico('check')}${esc(s)}</li>`).join('');
        if (j.status !== 'running') {
          clearInterval(timer);
          $('#jobClose').hidden = false;
          if (j.status === 'error') { $('#jobErr').hidden = false; $('#jobErr').textContent = j.error; reject(new Error(j.error)); } else { setTimeout(() => d.close(), 600); resolve(j.result); }
        }
      } catch (e) { clearInterval(timer); d.close(); reject(e); }
    }, 1000);
  });
}

/* ---------- theme */
function setTheme(t) {
  document.documentElement.dataset.theme = t; localStorage.setItem('uiavm-theme', t);
  $$('.theme-dots button').forEach(b => b.classList.toggle('on', b.dataset.t === t));
  if (document.body.dataset.auth === '1') api('/profile/update', {theme: t}).catch(() => {});
}

/* ---------- command palette */
(function () {
  const d = dlg('palette'); if (!d) return;
  const inp = $('input', d), list = $('ul', d); let items = [], sel = 0, tm;
  const draw = () => { list.innerHTML = items.length ? items.map((r, i) => `<li class="${i === sel ? 'on' : ''}"><a href="${esc(r.url)}">${ico({page: 'chevron', vps: 'server', node: 'nodes', user: 'user'}[r.kind] || 'chevron', 'sm')}<span>${esc(r.title)}</span><small>${esc(r.sub)}</small></a></li>`).join('') : `<li class="muted" style="padding:14px">Nothing matches "${esc(inp.value)}".</li>`; };
  const load = async () => { try { items = await get('/api/search?q=' + encodeURIComponent(inp.value)); sel = 0; draw(); } catch (e) {} };
  const open = () => { d.showModal(); inp.value = ''; load(); inp.focus(); };
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); d.open ? d.close() : open(); }
    else if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && !document.querySelector('dialog[open]')) { e.preventDefault(); open(); }
  });
  $$('[data-palette]').forEach(b => b.addEventListener('click', open));
  inp.addEventListener('input', () => { clearTimeout(tm); tm = setTimeout(load, 140); });
  inp.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { sel = Math.min(items.length - 1, sel + 1); draw(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); draw(); e.preventDefault(); }
    else if (e.key === 'Enter' && items[sel]) location.href = items[sel].url;
  });
  d.addEventListener('click', e => { if (e.target === d) d.close(); });
})();

/* ---------- topbar menus + notifications + realtime */
function pop(btn, menu, onOpen) {
  btn.addEventListener('click', e => { e.stopPropagation(); const o = !menu.classList.contains('open'); $$('.menu-pop.open').forEach(m => m.classList.remove('open')); menu.classList.toggle('open', o); if (o && onOpen) onOpen(); });
  menu.addEventListener('click', e => e.stopPropagation());
}
document.addEventListener('click', () => $$('.menu-pop.open').forEach(m => m.classList.remove('open')));
document.addEventListener('keydown', e => { if (e.key === 'Escape') $$('.menu-pop.open').forEach(m => m.classList.remove('open')); });

function setUnread(n) { const b = $('#bellDot'); if (b) { b.textContent = n > 99 ? '99+' : n; b.hidden = !n; } const r = $('#navUnread'); if (r) { r.textContent = n; r.hidden = !n; } }

document.addEventListener('DOMContentLoaded', () => {
  const m = $('#railToggle'); if (m) m.addEventListener('click', () => $('.rail').classList.toggle('open'));
  document.addEventListener('click', e => { if (!e.target.closest('.rail,#railToggle')) $('.rail')?.classList.remove('open'); });
  const bell = $('#bellBtn');
  if (bell) pop(bell, $('#bellMenu'), async () => {
    const j = await get('/api/notifications'); setUnread(j.unread);
    $('#bellList').innerHTML = j.items.length ? j.items.map(n => `<a class="n ${n.read ? '' : 'unread'}" href="/notifications"><b>${esc(n.title)}</b><span class="muted">${esc(n.message)}</span><small>${esc(n.ago)}</small></a>`).join('') : '<div class="empty" style="padding:22px">You are all caught up.</div>';
  });
  const imp = $('#impStop'); if (imp) imp.addEventListener('click', () => busy(imp, async () => { const r = await api('/impersonate/stop', {}); location.href = r.url; }));
  const um = $('#userBtn'); if (um) pop(um, $('#userMenu'));
  $$('.theme-dots button').forEach(b => b.addEventListener('click', () => setTheme(b.dataset.t)));
  $$('form[data-logout]').forEach(f => f.addEventListener('submit', () => localStorage.removeItem('uiavm-theme')));
  if (typeof io !== 'undefined' && document.body.dataset.auth === '1') {
    window.sock = io({transports: ['websocket', 'polling']});
    sock.on('notification', n => { toast(n.title, n.message, {success: 'success', error: 'error', warn: 'warn'}[n.type] || 'info'); const b = $('#bellDot'); setUnread((parseInt(b?.textContent) || 0) + 1); });
  }
});

/* ---------- shared: apply live rows to any element tagged data-vps="<id>" */
function applyVps(rows) {
  rows.forEach(r => {
    const el = $(`[data-vps="${r.id}"]`); if (!el) return;
    const st = r.suspended ? 'suspended' : (!r.node_online ? 'offline' : r.status);
    const p = $('[data-f=status]', el); if (p) { p.className = 'pill ' + st; p.textContent = st; }
    const set = (f, t) => { const n = $(`[data-f=${f}]`, el); if (n) n.textContent = t; };
    const on = r.status === 'running';
    set('cpu', on ? r.cpu.toFixed(0) + '%' : '-'); set('ram', on ? r.ram_pct.toFixed(0) + '%' : '-');
    setBar($('[data-f=cpubar]', el), on ? r.cpu : 0); setBar($('[data-f=rambar]', el), on ? r.ram_pct : 0);
    el.dataset.state = st;
  });
}
const STATUS_ICON = {start: 'play', stop: 'stop', restart: 'restart'};
async function power(id, action, btn) {
  if (action === 'stop' && !await confirmBox({title: 'Stop this VPS?', text: 'Running processes will be shut down. Data on disk is kept.', confirm: 'Stop VPS', danger: true})) return;
  return busy(btn, async () => { await api(`/vps/${id}/power/${action}`, {}); toast('Done', `VPS ${action === 'stop' ? 'stopped' : action === 'start' ? 'started' : action + 'ed'}.`, 'success'); setTimeout(() => location.reload(), 500); });
}

/* ---------- v12: animated numbers, cluster map, top-bar cluster pill */
function animNum(el, to, {dec = 0, suf = ''} = {}) {
  if (!el) return; to = +to || 0; const from = el._v ?? to;
  if (from === to || matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = to.toFixed(dec) + suf; el._v = to; return; }
  const t0 = performance.now(), D = 600; cancelAnimationFrame(el._r);
  const step = n => { const k = Math.min(1, (n - t0) / D), e = 1 - Math.pow(1 - k, 3); el.textContent = (from + (to - from) * e).toFixed(dec) + suf; if (k < 1) el._r = requestAnimationFrame(step); else el._v = to; };
  el._v = to; el._r = requestAnimationFrame(step);
}

/* nodes orbit the panel; packets flow along links; each orb carries a CPU arc */
function clusterMap(canvas) {
  let nodes = [], run = true; const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const col = {online: '--sig', draining: '--warn', offline: '--bad', pending: '--dim'};
  function frame(now) {
    if (!run) return; const [x, w, h] = sizeCanvas(canvas); const cx = w / 2, cy = h / 2, R = Math.min(w * .38, h * .36), t = now / 1000;
    x.font = '500 12px "Chakra Petch", sans-serif'; x.textAlign = 'center';
    x.strokeStyle = cssVar('--line'); x.setLineDash([2, 6]); x.lineWidth = 1; x.beginPath(); x.arc(cx, cy, R, 0, 6.283); x.stroke(); x.setLineDash([]);
    x.beginPath(); x.arc(cx, cy, R * 1.28, 0, 6.283); x.strokeStyle = cssVar('--line') + '88'; x.stroke();
    const n = nodes.length || 1;
    nodes.forEach((nd, i) => {
      const a = (n === 1 ? -.8 : -Math.PI / 2 + i * 2 * Math.PI / n) + (reduce ? 0 : Math.sin(t * .25 + i) * .03), nx = cx + Math.cos(a) * R, ny = cy + Math.sin(a) * R, c = cssVar(col[nd.state] || '--dim');
      x.strokeStyle = c + (nd.online ? '66' : '33'); x.lineWidth = 1; if (!nd.online) x.setLineDash([3, 5]); x.beginPath(); x.moveTo(cx, cy); x.lineTo(nx, ny); x.stroke(); x.setLineDash([]);
      if (nd.online && !reduce) for (let k = 0; k < 2; k++) { const p = ((t * .32 + i * .21 + k * .5) % 1), dir = k ? 1 - p : p; x.fillStyle = c; x.globalAlpha = .9 * Math.sin(Math.PI * p); x.beginPath(); x.arc(cx + (nx - cx) * dir, cy + (ny - cy) * dir, 2.2, 0, 6.283); x.fill(); x.globalAlpha = 1; }
      const r = 13 + Math.min(6, (nd.vps_count || 0) / Math.max(1, nd.total_vps) * 24);
      x.fillStyle = cssVar('--deck'); x.beginPath(); x.arc(nx, ny, r, 0, 6.283); x.fill();
      x.lineWidth = 3; x.strokeStyle = cssVar('--line'); x.beginPath(); x.arc(nx, ny, r + 4, 0, 6.283); x.stroke();
      if (nd.online) { x.strokeStyle = c; x.beginPath(); x.arc(nx, ny, r + 4, -Math.PI / 2, -Math.PI / 2 + Math.max(.04, nd.cpu / 100) * 6.283); x.stroke(); }
      x.fillStyle = c; x.beginPath(); x.arc(nx, ny, 4, 0, 6.283); x.fill();
      x.fillStyle = cssVar('--text'); const ly = ny + (Math.sin(a) > .3 ? r + 22 : -r - 12); x.fillText(nd.name.length > 14 ? nd.name.slice(0, 13) + '…' : nd.name, nx, ly);
    });
    const pulse = reduce ? 0 : (t % 3) / 3; x.strokeStyle = cssVar('--sig'); x.globalAlpha = (1 - pulse) * .5; x.lineWidth = 1.5; x.beginPath(); x.arc(cx, cy, 20 + pulse * 40, 0, 6.283); x.stroke(); x.globalAlpha = 1;
    const g = x.createRadialGradient(cx, cy, 2, cx, cy, 24); g.addColorStop(0, cssVar('--sig')); g.addColorStop(1, cssVar('--sig-2')); x.fillStyle = g; x.beginPath(); x.arc(cx, cy, 20, 0, 6.283); x.fill();
    x.fillStyle = cssVar('--on-sig'); x.font = '700 12px "Chakra Petch", sans-serif'; x.fillText('UIA', cx, cy + 4);
    if (!reduce && !document.hidden) requestAnimationFrame(frame);
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) requestAnimationFrame(frame); });
  requestAnimationFrame(frame);
  return {set(n) { nodes = n; if (reduce) requestAnimationFrame(frame); }, stop() { run = false; }};
}

document.addEventListener('DOMContentLoaded', () => {
  const pill = $('#clusterPill'); if (!pill) return;
  const upd = async () => { if (document.hidden) return; try { const d = await get('/api/live'); if (!d.cluster) return; const c = d.cluster, bad = c.online < c.nodes;
    pill.className = 'pill ' + (c.online === 0 ? 'offline' : bad ? 'warn' : 'online'); $('#clusterPillT').textContent = `${c.online}/${c.nodes} nodes`; } catch (e) {} };
  upd(); setInterval(upd, 8000);
});


/* ---------- v12.1: app-wide ambience (same look as the login page) */
document.addEventListener('DOMContentLoaded', () => { const c = $('#appnet'); if (c && window.fxNetwork) fxNetwork(c, {maxP: 60, minP: 22, dens: 26000, link: 150, alpha: .5, mouse: false, packets: false}); });
document.addEventListener('pointermove', e => {
  const p = e.target.closest && e.target.closest('.panel'); if (!p || p.classList.contains('pal')) return;
  const r = p.getBoundingClientRect(); p.style.setProperty('--gx', (e.clientX - r.left) + 'px'); p.style.setProperty('--gy', (e.clientY - r.top) + 'px');
}, {passive: true});
