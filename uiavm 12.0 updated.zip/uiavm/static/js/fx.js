/* UIAVM visual effects shared by the login page and the app: drifting network + rotating globe     made by reon */
(function () {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches, root = document.documentElement;
  const css = n => getComputedStyle(root).getPropertyValue(n).trim() || '#4fd8ff';
  const rgb = h => { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/(.)/g, '$1$1'); return [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)).join(','); };
  const DPR = () => Math.min(2, devicePixelRatio || 1);

  /* drifting topology; o = {maxP, minP, dens, link, alpha, mouse, packets} */
  window.fxNetwork = function (nv, o = {}) {
    if (!nv) return;
    const O = Object.assign({maxP: 90, minP: 30, dens: 18000, link: 140, alpha: 1, mouse: true, packets: true}, o);
    const x = nv.getContext('2d'); let W, H, P = [], K = [], mouse = {x: -999, y: -999}, col = css('--sig'), tick = 0;
    function size() {
      const d = DPR(); W = innerWidth; H = innerHeight; nv.width = W * d; nv.height = H * d; x.setTransform(d, 0, 0, d, 0, 0);
      const n = Math.max(O.minP, Math.min(O.maxP, Math.round(W * H / O.dens)));
      P = Array.from({length: n}, () => ({x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35, r: .9 + Math.random() * 1.7, z: .4 + Math.random() * .6}));
      K = [];
    }
    function frame() {
      if (tick++ % 40 === 0) col = css('--sig');
      const c = rgb(col), A = O.alpha; x.clearRect(0, 0, W, H);
      for (const p of P) { if (!reduce) { p.x += p.vx * p.z; p.y += p.vy * p.z; } if (p.x < -20) p.x = W + 20; if (p.x > W + 20) p.x = -20; if (p.y < -20) p.y = H + 20; if (p.y > H + 20) p.y = -20; }
      const all = O.mouse ? P.concat([{x: mouse.x, y: mouse.y, m: 1, z: 1}]) : P;
      for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) {
        const a = all[i], b = all[j], d = Math.hypot(a.x - b.x, a.y - b.y), L = (a.m || b.m) ? O.link * 1.45 : O.link;
        if (d < L) { x.strokeStyle = `rgba(${c},${(1 - d / L) * ((a.m || b.m) ? .55 : .22) * Math.min(a.z, b.z) * A})`; x.lineWidth = 1; x.beginPath(); x.moveTo(a.x, a.y); x.lineTo(b.x, b.y); x.stroke();
          if (O.packets && !reduce && !a.m && !b.m && d < 90 && Math.random() < .0009 && K.length < 14) K.push({a, b, t: 0}); }
      }
      K = K.filter(k => (k.t += .018) < 1);
      for (const k of K) { x.fillStyle = `rgba(${c},${.95 * A})`; x.shadowColor = `rgb(${c})`; x.shadowBlur = 8; x.beginPath(); x.arc(k.a.x + (k.b.x - k.a.x) * k.t, k.a.y + (k.b.y - k.a.y) * k.t, 2.2, 0, 6.283); x.fill(); x.shadowBlur = 0; }
      for (const p of P) { x.fillStyle = `rgba(${c},${(.35 + .5 * p.z) * A})`; x.beginPath(); x.arc(p.x, p.y, p.r * p.z + .3, 0, 6.283); x.fill(); }
      if (!reduce && !document.hidden) requestAnimationFrame(frame);
    }
    size(); frame();
    addEventListener('resize', () => { size(); if (reduce) frame(); });
    if (O.mouse) addEventListener('mousemove', e => { mouse.x = e.clientX; mouse.y = e.clientY; });
    document.addEventListener('visibilitychange', () => { if (!document.hidden && !reduce) frame(); });
  };

  /* rotating globe of connected nodes; o = {alpha} */
  window.fxGlobe = function (gv, o = {}) {
    if (!gv || getComputedStyle(gv).display === 'none') return;
    const A = o.alpha ?? 1, x = gv.getContext('2d'); let S = 0, ang = .6, last = performance.now(), sig = css('--sig'), sig2 = css('--sig-2'), tk = 0;
    const N = 560, G = Math.PI * (3 - Math.sqrt(5)), dots = [];
    for (let i = 0; i < N; i++) { const y = 1 - i / (N - 1) * 2, r = Math.sqrt(1 - y * y); dots.push([Math.cos(G * i) * r, y, Math.sin(G * i) * r]); }
    const ll = (lat, lon) => { const a = lat * Math.PI / 180, b = lon * Math.PI / 180; return [Math.cos(a) * Math.sin(b), Math.sin(a), Math.cos(a) * Math.cos(b)]; };
    const hubs = [[1.35, 103.8], [50.1, 8.7], [38.9, -77], [35.7, 139.7], [51.5, -.1], [-33.9, 151.2], [19.1, 72.9], [-23.5, -46.6], [37.4, -122], [25.2, 55.3], [-26.2, 28], [48.9, 2.3]].map(h => ll(h[0], h[1]));
    const arcs = [[0, 1], [1, 2], [2, 8], [8, 3], [3, 0], [0, 6], [6, 9], [9, 1], [4, 2], [5, 0], [7, 2], [10, 9], [11, 4], [5, 3]];
    const norm = v => { const l = Math.hypot(...v); return v.map(c => c / l); }, tilt = .38;
    const rot = (v, a) => { const x1 = v[0] * Math.cos(a) + v[2] * Math.sin(a), z1 = -v[0] * Math.sin(a) + v[2] * Math.cos(a); return [x1, v[1] * Math.cos(tilt) - z1 * Math.sin(tilt), v[1] * Math.sin(tilt) + z1 * Math.cos(tilt)]; };
    function size() { const r = gv.getBoundingClientRect(), d = DPR(); S = r.width; gv.width = r.width * d; gv.height = r.width * d; x.setTransform(d, 0, 0, d, 0, 0); }
    function frame(now) {
      if (tk++ % 60 === 0) { sig = css('--sig'); sig2 = css('--sig-2'); }
      if (!reduce) ang += (now - last) * .00008; last = now;
      const R = S * .42, cx = S / 2, cy = S / 2, c1 = rgb(sig), c2 = rgb(sig2); x.clearRect(0, 0, S, S);
      const pj = v => { const f = 1 / (1 - v[2] * .18); return [cx + v[0] * R * f, cy - v[1] * R * f, v[2]]; };
      const g = x.createRadialGradient(cx - R * .25, cy - R * .3, R * .1, cx, cy, R * 1.05); g.addColorStop(0, `rgba(${c1},${.07 * A})`); g.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = g; x.beginPath(); x.arc(cx, cy, R * 1.02, 0, 6.283); x.fill();
      x.strokeStyle = `rgba(${c1},${.22 * A})`; x.lineWidth = 1; x.beginPath(); x.arc(cx, cy, R, 0, 6.283); x.stroke();
      x.strokeStyle = `rgba(${c1},${.08 * A})`; x.beginPath(); x.arc(cx, cy, R * 1.12, 0, 6.283); x.stroke();
      for (const d of dots) { const p = pj(rot(d, ang)); if (p[2] > -.05) { x.fillStyle = `rgba(${c1},${(.2 + .6 * p[2]) * A})`; x.fillRect(p[0], p[1], 1.8, 1.8); } else { x.fillStyle = `rgba(${c1},${.05 * A})`; x.fillRect(p[0], p[1], 1, 1); } }
      const t = now / 1000;
      arcs.forEach(([ia, ib], k) => {
        const a = hubs[ia], b = hubs[ib], seg = [];
        for (let s = 0; s <= 28; s++) { const u = s / 28, v = norm([a[0] * (1 - u) + b[0] * u, a[1] * (1 - u) + b[1] * u, a[2] * (1 - u) + b[2] * u]), h = 1 + .24 * Math.sin(Math.PI * u); seg.push(pj(rot(v.map(c => c * h), ang))); }
        x.lineWidth = 1.1;
        for (let s = 1; s < seg.length; s++) { const z = (seg[s][2] + seg[s - 1][2]) / 2; if (z < -.15) continue; x.strokeStyle = `rgba(${c2},${(.12 + .5 * Math.max(0, z)) * A})`; x.beginPath(); x.moveTo(seg[s - 1][0], seg[s - 1][1]); x.lineTo(seg[s][0], seg[s][1]); x.stroke(); }
        if (!reduce) { const u = (t * .16 + k * .23) % 1, i = Math.min(27, Math.floor(u * 28)), pz = seg[i][2]; if (pz > -.1) { x.shadowColor = `rgb(${c1})`; x.shadowBlur = 10; x.fillStyle = `rgba(${c1},${.95 * A})`; x.beginPath(); x.arc(seg[i][0], seg[i][1], 2.4, 0, 6.283); x.fill(); x.shadowBlur = 0; } }
      });
      hubs.forEach((h, i) => { const p = pj(rot(h, ang)); if (p[2] < -.05) return; const pulse = reduce ? 0 : ((t * .5 + i * .31) % 1);
        x.strokeStyle = `rgba(${c1},${(1 - pulse) * .6 * A})`; x.lineWidth = 1.2; x.beginPath(); x.arc(p[0], p[1], 4 + pulse * 14, 0, 6.283); x.stroke();
        x.fillStyle = `rgba(${c1},${A})`; x.shadowColor = `rgb(${c1})`; x.shadowBlur = 12; x.beginPath(); x.arc(p[0], p[1], 3.2, 0, 6.283); x.fill(); x.shadowBlur = 0; });
      if (!reduce && !document.hidden) requestAnimationFrame(frame);
    }
    size(); requestAnimationFrame(frame);
    addEventListener('resize', () => { size(); if (reduce) requestAnimationFrame(frame); });
    document.addEventListener('visibilitychange', () => { if (!document.hidden && !reduce) { last = performance.now(); requestAnimationFrame(frame); } });
  };
})();
